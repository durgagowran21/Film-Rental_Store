export interface Category {
  id?: number;
  name: string;
  lastUpdate?: string;
}