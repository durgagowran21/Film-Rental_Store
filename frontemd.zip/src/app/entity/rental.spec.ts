import { Rental } from './rental';

describe('Rental', () => {
  it('should create an instance', () => {
    expect(new Rental()).toBeTruthy();
  });
});
