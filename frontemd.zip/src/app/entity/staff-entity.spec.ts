import { StaffEntity } from './staff-entity';

describe('StaffEntity', () => {
  it('should create an instance', () => {
    expect(new StaffEntity()).toBeTruthy();
  });
});
