export interface PaymentDTO {
  paymentId: number;          // @NotNull
  customerId: number;         // @NotNull
  staffId: number;            // @NotNull
  rentalId?: number;          // optional in DTO
  amount: number;             // @Positive
  paymentDate?: string;       // ISO string (LocalDateTime)
  lastUpdate?: string;        // ISO string
}
