export interface InventoryDTO {
  inventoryId: number;
  filmId: number;
  storeId: number;
  lastUpdate: string;
}