
export interface FilmDto {
  filmId?: number;
  title: string;
  description?: string;
  releaseYear?: number;
  languageId: number; // backend uses Integer; your DTO shows Long; we use number in TS
  rentalDuration?: number;
  rentalRate?: number;
  length?: number;
  replacementCost?: number;
  rating?: number;
  specialFeatures?: string;
}

export interface ActorDto {
  id: number;           // from your ActorDto
  firstName: string;
  lastName: string;
}

export interface Language {
  languageId: number;
  name: string;
}

export interface Category {
  categoryId: number;
  name: string;
}

export type FilmCountByYear = Record<number, number>;
