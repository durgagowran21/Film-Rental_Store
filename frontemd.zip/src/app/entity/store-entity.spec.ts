import { StoreEntity } from './store-entity';

describe('StoreEntity', () => {
  it('should create an instance', () => {
    expect(new StoreEntity()).toBeTruthy();
  });
});
