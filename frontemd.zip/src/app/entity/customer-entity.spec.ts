import { CustomerEntity } from './customer-entity';

describe('CustomerEntity', () => {
  it('should create an instance', () => {
    expect(new CustomerEntity()).toBeTruthy();
  });
});
