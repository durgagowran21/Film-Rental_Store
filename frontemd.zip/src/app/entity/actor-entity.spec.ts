import { ActorEntity } from './actor-entity';

describe('ActorEntity', () => {
  it('should create an instance', () => {
    expect(new ActorEntity()).toBeTruthy();
  });
});
