export interface CustomerDto {
  customerId?: number;              
  firstName?: string;
  lastName?: string;
  email?: string;
  active?: boolean;
  addressId: number;                
  storeId: number;                  
  createDate?: string | null;       
  lastUpdate?: string | null;       
}

// --- Staff DTO ---
export interface StaffDTO {
  staffId?: number;                 // READ_ONLY
  firstName: string;
  lastName: string;
  addressId: number;
  email?: string;
  storeId: number;
  active?: boolean;
  username: string;
  password: string;
  lastUpdate?: string | null;
}

// --- Minimal associated models ---
export interface AddressDto {
  addressId: number;
  phone?: string;
}

// --- Store ENTITY (what /api/stores/all returns) ---
export interface StoreModel {
  storeId: number;
  address?: AddressDto | null;
  customers?: CustomerDto[] | null;
  staffList?: StaffDTO[] | null;    // entity uses 'staffList'
  lastUpdate?: string | null;
}

// --- Store DTO (used by create/assign/search) ---
export interface StoreDto {
  storeId?: number;                 // READ_ONLY
  address?: AddressDto | null;
  addressID: number;                // used for create/assign
  lastUpdate?: string | null;
  customers?: CustomerDto[] | null;
  staff_list?: StaffDTO[] | null;   // dto uses 'staff_list'
}

// --- StoreIdDTO (country search result) ---
export interface StoreIdDTO {
  storeId: number;
  phone: string;
}

