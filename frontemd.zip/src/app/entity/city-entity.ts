export interface CityDto {
  id?: number;
  city: string;
  countryId: number;
  lastUpdate?: string;
}