 
export interface CustomerDto {
  customerId?: number;
  firstName: string;
  lastName: string;
  email?: string;
  active?: boolean;
  addressId: number;
  storeId: number;
  createDate?: string;   
  lastUpdate?: string;   
}
 
export interface Store {
  storeId: number;
}
 
export interface Address {
  addressId: number;
}
 
 