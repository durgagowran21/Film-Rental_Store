export interface AddressDto {
  id?: number;
  address: string;
  address2?: string;
  district: string;
  cityId: number;
  postalCode?: string;
  phone: string;
  lastUpdate?: string;
}