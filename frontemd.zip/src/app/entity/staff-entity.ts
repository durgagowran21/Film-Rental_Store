export interface StaffEntity {

  id: number;
  firstName: string;
  lastName: string;
  email: string | null;
  phone: string | null;
  storeId: number | null;
  addressId: number | null;
  active?: boolean;
  username?: string;
  lastUpdate?: string;
}

// DTOs matching your Spring records
export interface StaffFirstNameUpdateRequest { firstName: string; }
export interface StaffLastNameUpdateRequest  { lastName: string; }
export interface StaffEmailUpdateRequest     { email: string; }
export interface StaffPhoneUpdateRequest     { phone: string; }
export interface StaffStoreAssignRequest     { storeId: number; }
export interface StaffAddressAssignRequest   { addressId: number; }
