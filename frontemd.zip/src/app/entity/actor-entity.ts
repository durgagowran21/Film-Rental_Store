export interface ActorDto {
  id: number;
  firstName: string;
  lastName: string;
}

export interface ActorEntity {
  id: number;
  firstName: string;
  lastName: string;
  fullName: string;
  _dto: ActorDto;
}
 
export interface LanguageInfo {
  languageId: number;
  name: string;
  lastUpdate?: string;
}
 
export interface Film {
  filmId: number;
  title: string;
  description?: string;
  releaseYear?: number;
  language?: LanguageInfo;
  rentalDuration?: number;
  rentalRate?: number;
  length?: number;
  replacementCost?: number;
  rating?: string;
  specialFeatures?: string;
  lastUpdate?: string;
}
 
 