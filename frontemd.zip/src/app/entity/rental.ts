export interface RentalDto {
  rentalId: number;           // @Positive
  inventoryId: number;        // @Positive
  customerId: number;         // @Positive
  staffId: number;            // @Positive
  returnDate?: string | null; // ISO string or null
  rentalDate?: string;        // ISO string
  lastUpdate?: string;        // ISO string
}
