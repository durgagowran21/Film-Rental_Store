import { ComponentFixture, TestBed } from '@angular/core/testing';

import { RoleToggle } from './role-toggle';

describe('RoleToggle', () => {
  let component: RoleToggle;
  let fixture: ComponentFixture<RoleToggle>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [RoleToggle]
    })
    .compileComponents();

    fixture = TestBed.createComponent(RoleToggle);
    component = fixture.componentInstance;
    await fixture.whenStable();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
