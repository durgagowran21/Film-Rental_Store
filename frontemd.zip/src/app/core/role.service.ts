// src/app/core/role.service.ts
import { Injectable, Inject, PLATFORM_ID } from '@angular/core';
import { isPlatformBrowser } from '@angular/common';
import { BehaviorSubject } from 'rxjs';

export type Role = 'customer' | 'staff';

@Injectable({ providedIn: 'root' })
export class RoleService {
  private readonly STORAGE_KEY = 'app.role';
  private readonly isBrowser: boolean;

  /** Reactive role stream */
  private readonly _role$ = new BehaviorSubject<Role>('customer');
  readonly role$ = this._role$.asObservable();

  /** Current role snapshot */
  get role(): Role {
    return this._role$.value;
  }

  constructor(@Inject(PLATFORM_ID) platformId: Object) {
    this.isBrowser = isPlatformBrowser(platformId);

    // Initialize safely
    const initial = this.readRoleFromStorage();
    this._role$.next(initial);
  }

  setRole(role: Role) {
    this._role$.next(role);
    this.writeRoleToStorage(role);
  }

  /** Convenience helpers used by directives/UI */
  isCustomer(): boolean {
    return this._role$.value === 'customer';
  }
  isStaff(): boolean {
    return this._role$.value === 'staff';
  }

  // ---- Safe storage helpers ----
  private readRoleFromStorage(): Role {
    if (!this.isBrowser) return 'customer';
    try {
      const raw = window.localStorage.getItem(this.STORAGE_KEY);
      return (raw === 'staff' || raw === 'customer') ? raw : 'customer';
    } catch {
      return 'customer';
    }
  }

  private writeRoleToStorage(role: Role): void {
    if (!this.isBrowser) return;
    try {
      window.localStorage.setItem(this.STORAGE_KEY, role);
    } catch {
      /* ignore write errors (private mode, quota, etc.) */
    }
  }
}
