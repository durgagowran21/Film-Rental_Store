// src/app/core/role-toggle.ts
import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RoleService, Role } from './role.service';

@Component({
  selector: 'app-role-toggle',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './role-toggle.html',
  styleUrls: ['./role-toggle.scss'],
})
export class RoleToggleComponent {
  current: Role;

  constructor(private roleSvc: RoleService) {
    this.current = this.roleSvc.role;
  }

  setRole(role: Role) {
    this.current = role;
    this.roleSvc.setRole(role);
  }
}
