import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { HttpClient } from '@angular/common/http';
import { RouterOutlet } from '@angular/router';

@Component({
  standalone: true,
  selector: 'pending-returns',
  imports: [CommonModule,RouterOutlet],
  templateUrl: './rentals-pending-returns.html',
  styleUrls: ['./rentals-pending-returns.css']
})
export class PendingReturnsComponent {
  data: any = {};
  loading = false;
  error: string | null = null;

  // ✅ Expose Object.keys to the template
  objectKeys = Object.keys;

  constructor(private http: HttpClient) {}

  ngOnInit(): void {
    // Optional auto-load
    // this.fetchPending();
  }

  fetchPending(): void {
    this.loading = true;
    this.error = null;
    // TODO: replace with your actual API URL (e.g., `${environment.apiBase}/rental/pending-returns`)
    this.http.get<any>('/api/rental/pending-returns').subscribe({
      next: (res) => {
        this.data = res ?? {};
        this.loading = false;
      },
      error: (err) => {
        this.error = 'Failed to load pending returns';
        console.error(err);
        this.loading = false;
      }
    });
  }
}
