import { ComponentFixture, TestBed } from '@angular/core/testing';

import { RentalsPendingReturns } from './rentals-pending-returns';

describe('RentalsPendingReturns', () => {
  let component: RentalsPendingReturns;
  let fixture: ComponentFixture<RentalsPendingReturns>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [RentalsPendingReturns]
    })
    .compileComponents();

    fixture = TestBed.createComponent(RentalsPendingReturns);
    component = fixture.componentInstance;
    await fixture.whenStable();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
