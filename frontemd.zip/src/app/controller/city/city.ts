import { Component } from '@angular/core';
import { FormBuilder, FormGroup, ReactiveFormsModule, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { CityServ } from '../../Service/city-serv';
import { CityDto } from '../../entity/city-entity';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-city',
  standalone: true,
  imports: [ReactiveFormsModule, CommonModule],
  templateUrl: './city.html',
  styleUrl: './city.css'
})
export class CityComponent {
  cityForm: FormGroup;
  message: string = '';

  constructor(
    private fb: FormBuilder,
    private cityServ: CityServ,
    private router: Router
  ) {
    this.cityForm = this.fb.group({
      city: ['', Validators.required],
      countryId: [null, Validators.required]
    });
  }

  onSubmit() {
    if (this.cityForm.valid) {
      const city: CityDto = this.cityForm.value;
      this.cityServ.createCity(city).subscribe({
        next: (response) => {
          this.message = response;
          this.cityForm.reset();
        },
        error: (err) => {
          this.message = 'Error creating city: ' + err.message;
        }
      });
    }
  }

  navigateTo(path: string) {
    this.router.navigate([path]);
  }
}