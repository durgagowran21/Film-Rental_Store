
import { Component, OnInit } from '@angular/core';
import { Router, RouterOutlet } from '@angular/router';

import { CommonModule } from '@angular/common';
import {
  NonNullableFormBuilder,
  FormGroup,
  FormControl,
  ReactiveFormsModule
} from '@angular/forms';

import { MatSnackBar, MatSnackBarModule } from '@angular/material/snack-bar';


import { RoleService } from '../../core/role.service';
import { FilmDto, FilmCountByYear } from '../../entity/film.model';
import { FilmService } from '../../Service/film';

type Cmp = 'gt' | 'lt';

type FiltersForm = {
  title:       FormControl<string>;
  releaseYear: FormControl<string>;
  durationCmp: FormControl<Cmp>;
  durationVal: FormControl<string>;
  rateCmp:     FormControl<Cmp>;
  rateVal:     FormControl<string>;
  lengthCmp:   FormControl<Cmp>;
  lengthVal:   FormControl<string>;
  fromYear:    FormControl<string>;
  toYear:      FormControl<string>;
  ratingCmp:   FormControl<Cmp>;
  ratingVal:   FormControl<string>;
  language:    FormControl<string>;
  category:    FormControl<string>;
};

@Component({
  selector: 'app-film-list',
  templateUrl:'./film-list.html',
  styleUrls: ['./film-list.scss'],
  standalone: true,
  imports: [
    CommonModule,        // *ngIf, *ngFor, keyvalue pipe
    ReactiveFormsModule, // formGroup, formControlName
    MatSnackBarModule ,RouterOutlet   // provider for MatSnackBar
  ]
})
export class FilmListComponent implements OnInit {
  films: FilmDto[] = [];
  loading = false;
  error?: string;

  filters!: FormGroup<FiltersForm>;

  displayedColumns = [
    'filmId', 'title', 'releaseYear', 'languageId',
    'rentalRate', 'length', 'rating', 'actions'
  ];
countByYear?: FilmCountByYear;
constructor(
    private fb: NonNullableFormBuilder,
    private filmSvc: FilmService,
    private snack: MatSnackBar,
    public roleSvc: RoleService,
    private router: Router
  ) {}

 ngOnInit(): void {
    // Typed, non-nullable controls
    this.filters = this.fb.group({
      title:       this.fb.control(''),
      releaseYear: this.fb.control(''),
      durationCmp: this.fb.control<Cmp>('gt'),
      durationVal: this.fb.control(''),
      rateCmp:     this.fb.control<Cmp>('gt'),
      rateVal:     this.fb.control(''),
      lengthCmp:   this.fb.control<Cmp>('gt'),
      lengthVal:   this.fb.control(''),
      fromYear:    this.fb.control(''),
      toYear:      this.fb.control(''),
      ratingCmp:   this.fb.control<Cmp>('gt'),
      ratingVal:   this.fb.control(''),
      language:    this.fb.control(''),
      category:    this.fb.control(''),
    });

// this.loadAll();
  //this.loadCounts();
  }

  // --- Data calls ---
  loadAll(): void {
    this.loading = true;
    this.filmSvc.getAll().subscribe({
      next: (res) => { this.films = res; this.loading = false; },
      error: (err) => {
        this.error = err?.error?.message ?? 'Failed to load films';
        this.loading = false;
      }
    });
  }

//  loadCounts(): void {
//     this.filmSvc.countByYear().subscribe({
//       next: (res) => this.countByYear = res,
//       error: () => {}
//     });
//   }

  // // --- Filters ---
  // applyTitle(): void {
  //   const t = this.filters.get('title')!.value.trim();
  //   if (!t) return this.toast('Enter title');
  //   this.loading = true;
  //   this.filmSvc.findByTitle(t).subscribe({
  //     next: (res) => { this.films = res ? [res] : []; this.loading = false; },
  //     error: (err) => { this.toast(err?.error?.message || 'No film found'); this.loading = false; }
  //   });
    
  // }
  
applyTitle(): void {
  const t = this.filters.get('title')!.value.trim();
  if (!t) return this.toast('Enter title');

  this.loading = true;
  this.filmSvc.findByTitle(t).subscribe({
    next: (res) => {
      console.log('[applyTitle] response:', res); // <— log raw
      // Robust: accept FilmDto OR FilmDto[] just in case server changes later
      const list = Array.isArray(res) ? res : (res ? [res] : []);
      this.films = list;
      console.log('[applyTitle] films.length:', this.films.length); // <— log
      this.loading = false;
    },
    error: (err) => {
      console.error('[applyTitle] error:', err);
      this.toast(err?.error?.message || 'No film found');
      this.loading = false;
    }
  });
}

  applyYear(): void {
    const y = Number(this.filters.get('releaseYear')!.value);
    if (!y) return this.toast('Enter release year');
    this.loading = true;
    this.filmSvc.findByReleaseYear(y).subscribe({
      next: (res) => { this.films = res; this.loading = false; },
      error: (err) => { this.toast(err?.error?.message || 'No records found'); this.loading = false; }
    });
  }
 applyDuration(): void {
    const val = Number(this.filters.get('durationVal')!.value);
    if (!val && val !== 0) return this.toast('Enter rental duration');
    const cmp = this.filters.get('durationCmp')!.value;
    const call = cmp === 'gt' ? this.filmSvc.findDurationGt(val) : this.filmSvc.findDurationLt(val);
    this.loading = true;
    call.subscribe({
      next: (res) => { this.films = res; this.loading = false; },
      error: (err) => { this.toast(err?.error?.message || 'No records found'); this.loading = false; }
    });
  }


applyRate(): void {
    const val = Number(this.filters.get('rateVal')!.value);
    if (!val && val !== 0) return this.toast('Enter rate');
    const call = this.filters.get('rateCmp')!.value === 'gt'
      ? this.filmSvc.findRateGt(val)
      : this.filmSvc.findRateLt(val);
    this.loading = true;
    call.subscribe({
      next: (res) => { this.films = res; this.loading = false; },
      error: (err) => { this.toast(err?.error?.message || 'No records found'); this.loading = false; }
    });
  }

applyLength(): void {
    const val = Number(this.filters.get('lengthVal')!.value);
    if (!val && val !== 0) return this.toast('Enter length');
    const call = this.filters.get('lengthCmp')!.value === 'gt'
      ? this.filmSvc.findLengthGt(val)
      : this.filmSvc.findLengthLt(val);
    this.loading = true;
    call.subscribe({
      next: (res) => { this.films = res; this.loading = false; },
      error: (err) => { this.toast(err?.error?.message || 'No records found'); this.loading = false; }
    });
  }
  applyBetweenYears(): void {
    const from = Number(this.filters.get('fromYear')!.value);
    const to   = Number(this.filters.get('toYear')!.value);
    if (!from || !to) return this.toast('Enter from/to year');
    this.loading = true;
    this.filmSvc.findBetweenYear(from, to).subscribe({
      next: (res) => { this.films = res; this.loading = false; },
      error: (err) => { this.toast(err?.error?.message || 'No records found'); this.loading = false; }
    });
  }

 applyRating(): void {
    const val = Number(this.filters.get('ratingVal')!.value);
    if (!val && val !== 0) return this.toast('Enter rating');
    const call = this.filters.get('ratingCmp')!.value === 'gt'
      ? this.filmSvc.findRatingGt(val)
      : this.filmSvc.findRatingLt(val);
    this.loading = true;
    call.subscribe({
      next: (res) => { this.films = res; this.loading = false; },
      error: (err) => { this.toast(err?.error?.message || 'No records found'); this.loading = false; }
    });
  }

 applyLanguage(): void {
    const lang = this.filters.get('language')!.value.trim();
    if (!lang) return this.toast('Enter language name');
    this.loading = true;
    this.filmSvc.findByLanguage(lang).subscribe({
      next: (res) => { this.films = res; this.loading = false; },
      error: (err) => { this.toast(err?.error?.message || 'No records found'); this.loading = false; }
    });
  }

 applyCategory(): void {
    const cat = this.filters.get('category')!.value.trim();
    if (!cat) return this.toast('Enter category name');
    this.loading = true;
    this.filmSvc.getFilmsByCategory(cat).subscribe({
      next: (res) => { this.films = res; this.loading = false; },
      error: (err) => { this.toast(err?.error?.message || 'No records found'); this.loading = false; }
    });
  }
  
//countByYear?: FilmCountByYear;

// refreshCounts(): void {
//   this.loading = true;
//   this.filmSvc.countByYear().subscribe({
//     next: (res) => { this.countByYear = res; this.loading = false; },
//     error: () => { this.toast('Failed to load counts'); this.loading = false; }
//   });
// }



//countByYear?: FilmCountByYear;

refreshCounts(): void {
  this.loading = true;
  this.filmSvc.countByYear().subscribe({
    next: (res) => {
      console.log('[counts] received:', res);
      this.countByYear = res;   // <-- must assign so *ngIf becomes true
      setTimeout(() => { this.loading = false; }); // avoids ExpressionChangedAfterItHasBeenCheckedError
    },
    error: (err) => {
      console.error('[counts] error:', err);
      this.toast(err?.error?.message || 'Failed to load counts');
      setTimeout(() => { this.loading = false; });
    }
  });
}


 // --- Navigation ---
  view(film: FilmDto): void {
    if (!film.filmId) return;
    this.router.navigate(['/film', film.filmId]);
  }

// --- Helpers ---
  private toast(msg: string): void {
    this.snack.open(msg, 'OK', { duration: 2500 });
  }

 /** Optional: use as trackBy for films table rows */
  trackFilm = (_: number, f: FilmDto) => f.filmId;
}