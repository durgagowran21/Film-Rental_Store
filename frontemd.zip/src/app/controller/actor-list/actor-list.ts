
import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { ActorDto } from '../../entity/actor-entity';
import { ActorServ as ActorService } from '../../Service/actor-serv';
@Component({
  selector: 'app-actor-list',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './actor-list.html',
  styleUrls: ['./actor-list.css']
})
export class ActorListComponent {
  firstQuery = '';
  lastQuery = '';
  results: ActorDto[] = [];
  topTen: ActorDto[] = [];
  loading = false;

  constructor(private svc: ActorService) {}

  searchFirst() {
    const q = this.firstQuery.trim();
    if (!q) return;
    this.loading = true;
    this.svc.searchByFirstName(q).subscribe({
      next: res => { this.results = res; this.loading = false; },
      error: err => { alert('Search (first) failed: ' + err.message); this.loading = false; }
    });
  }

  searchLast() {
    const q = this.lastQuery.trim();
    if (!q) return;
    this.loading = true;
    this.svc.searchByLastName(q).subscribe({
      next: res => { this.results = res; this.loading = false; },
      error: err => { alert('Search (last) failed: ' + err.message); this.loading = false; }
    });
  }

  loadTop() {
    this.loading = true;
    this.svc.getTopTenByFilmCount().subscribe({
      next: res => { this.topTen = res; this.loading = false; },
      error: err => { alert('Top-10 failed: ' + err.message); this.loading = false; }
    });
  }
}
