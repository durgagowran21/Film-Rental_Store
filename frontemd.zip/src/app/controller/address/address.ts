import { Component } from '@angular/core';
import { FormBuilder, FormGroup, ReactiveFormsModule, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { AddressServ } from '../../Service/address-serv';
import { AddressDto } from '../../entity/address-entity';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-address',
  standalone: true,
  imports: [ReactiveFormsModule, CommonModule],
  templateUrl: './address.html',
  styleUrl: './address.css'
})
export class AddressComponent {
  addressForm: FormGroup;
  message: string = '';

  constructor(
    private fb: FormBuilder,
    private addressServ: AddressServ,
    private router: Router
  ) {
    this.addressForm = this.fb.group({
      address: ['', Validators.required],
      address2: [''],
      district: ['', Validators.required],
      cityId: [null, Validators.required],
      postalCode: [''],
      phone: ['', Validators.required]
    });
  }

  onSubmit() {
    if (this.addressForm.valid) {
      const address: AddressDto = this.addressForm.value;
      this.addressServ.createAddress(address).subscribe({
        next: (response) => {
          this.message = response;
          this.addressForm.reset();
        },
        error: (err) => {
          this.message = 'Error creating address: ' + err.message;
        }
      });
    }
  }

  navigateTo(path: string) {
    this.router.navigate([path]);
  }
}