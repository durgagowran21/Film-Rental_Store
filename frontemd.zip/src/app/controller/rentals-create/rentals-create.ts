
import { Component } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { RentalDto } from '../../entity/rental';
import { RentalService } from '../../Service/rental';
import { RouterOutlet } from '@angular/router';


@Component({
  selector: 'app-rentals-create',
  standalone: true,
  imports: [CommonModule, FormsModule, RouterOutlet],
  templateUrl: './rentals-create.html',
  // styleUrls: ['./rentals-create.component.css'] // optional
})
export class RentalsCreateComponent {
  model: RentalDto = { rentalId: 0, inventoryId: 0, customerId: 0, staffId: 0 };
  message = '';
  error = '';
  loading = false; // optional

  constructor(private rental: RentalService) {}

  submit() {
    this.message = '';
    this.error = '';
    this.loading = true; // optional

    this.rental.addRental(this.model).subscribe({
      next: (msg) => {
        this.message = msg; // your service returns a string message
        this.loading = false;
      },
      error: (err) => {
        this.error = err?.error ?? 'Failed to create rental';
        this.loading = false;
      }
    });
  }
}
