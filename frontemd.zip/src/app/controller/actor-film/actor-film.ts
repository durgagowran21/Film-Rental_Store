
// src/app/components/actor-film/actor-film.component.ts
import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { ActorServ as ActorService } from '../../Service/actor-serv';
import { Film } from '../../entity/actor-entity';
import { Router } from '@angular/router';

@Component({
  selector: 'app-actor-film',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './actor-film.html',
  styleUrls: ['./actor-film.css']
})
export class ActorFilm {
  actorId!: number;
  filmIdsText = '';   // e.g., "1, 2, 3"
  films: Film[] = [];
  loading = false;

  constructor(private svc: ActorService, public route: Router) {}

  loadFilms() {
    if (!this.actorId) return alert('Provide actor id');
    this.loading = true;
    this.svc.getFilmsByActor(this.actorId).subscribe({
      next: res => { this.films = res; this.loading = false; },
      error: err => { alert('Load films failed: ' + err.message); this.loading = false; }
    });
  }

  linkFilms() {
    if (!this.actorId) return alert('Provide actor id');
    const ids = this.parseFilmIds(this.filmIdsText);
    if (!ids.length) return alert('Provide comma-separated film IDs');
    this.svc.addFilmsToActor(this.actorId, ids).subscribe({
      next: msg => { alert(msg); this.loadFilms(); },
      error: err => alert('Link failed: ' + err.message)
    });
  }

  private parseFilmIds(text: string): number[] {
    return text
      .split(',')
      .map(t => t.trim())
      .filter(t => t.length)
      .map(Number)
      .filter(n => !Number.isNaN(n));
  }

  
}

