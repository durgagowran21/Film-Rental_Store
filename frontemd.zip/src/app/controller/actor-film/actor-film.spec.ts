import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ActorFilm } from './actor-film';

describe('ActorFilm', () => {
  let component: ActorFilm;
  let fixture: ComponentFixture<ActorFilm>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [ActorFilm]
    })
    .compileComponents();

    fixture = TestBed.createComponent(ActorFilm);
    component = fixture.componentInstance;
    await fixture.whenStable();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
