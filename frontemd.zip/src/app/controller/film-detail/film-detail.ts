


import { Component, OnInit, OnDestroy } from '@angular/core';
import { ActivatedRoute, RouterOutlet } from '@angular/router';
import { CommonModule } from '@angular/common';
import { MatSnackBar, MatSnackBarModule } from '@angular/material/snack-bar';
import { Subject } from 'rxjs';
import { takeUntil } from 'rxjs/operators';

import { ActorDto } from '../../entity/film.model';
import { FilmService } from '../../Service/film';

@Component({
  selector: 'app-film-detail',
  templateUrl: './film-detail.html',
  styleUrls: ['./film-detail.scss'],
  standalone: true,
  imports: [
    CommonModule,        // for *ngIf, *ngFor, common pipes
    MatSnackBarModule, RouterOutlet  // provides MatSnackBar
  ],
})
export class FilmDetailComponent implements OnInit, OnDestroy {
  id!: number;
  actors: ActorDto[] = [];
  loading = false;

  private destroy$ = new Subject<void>();

  constructor(
    private route: ActivatedRoute,
    private filmSvc: FilmService,
    private snack: MatSnackBar
  ) {}

  ngOnInit(): void {
    // Read route param and load actors if id is present
    const rawId = this.route.snapshot.paramMap.get('id');
    this.id = Number(rawId);
    if (Number.isFinite(this.id) && this.id > 0) {
      this.loadActors();
    } else {
      this.snack.open('Invalid film id', 'OK', { duration: 2500 });
    }
  }

  ngOnDestroy(): void {
    this.destroy$.next();
    this.destroy$.complete();
  }

  loadActors(): void {
    this.loading = true;
    this.filmSvc.getActorsOfFilm(this.id)
      .pipe(takeUntil(this.destroy$))
      .subscribe({
        next: (res) => {
          this.actors = Array.isArray(res) ? res : [];
          this.loading = false;
        },
        error: (err) => {
          const msg = err?.error?.message ?? 'Failed to load actors';
          this.snack.open(msg, 'OK', { duration: 2500 });
          this.loading = false;
        },
      });
  }

  /** Optional: use in template as `trackBy: trackActor` for better list performance */
  trackActor = (_index: number, a: ActorDto) => a.id;
}
