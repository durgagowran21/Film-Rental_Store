import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { RentalDto } from '../../entity/rental';
import { RentalService } from '../../Service/rental';
import { RouterOutlet } from '@angular/router';

@Component({
  selector: 'app-top-ten-films-by-store',
  standalone: true,
  imports: [CommonModule, FormsModule,RouterOutlet],
  templateUrl: './rental-top-ten-films-by-store.html',
  // Optional: if you want styles separated too
  // styleUrls: ['./top-ten-films-by-store.component.css']
})
export class TopTenFilmsByStoreComponent {
  storeId?: number;
  rentals: RentalDto[] = [];
  loading = false;
  error = '';

  constructor(private svc: RentalService) {}

  load() {
    if (!this.storeId) return;
    this.loading = true;
    this.error = '';
    this.svc.getTopTenFilmsByStore(this.storeId).subscribe({
      next: (list) => {
        this.rentals = list ?? [];
        this.loading = false;
      },
      error: (err) => {
        this.error = (err?.message || 'Failed to load data');
        this.loading = false;
      }
    });
  }
}
