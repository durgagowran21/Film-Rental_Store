import { ComponentFixture, TestBed } from '@angular/core/testing';

import { RentalTopTenFilmsByStore } from './rental-top-ten-films-by-store';

describe('RentalTopTenFilmsByStore', () => {
  let component: RentalTopTenFilmsByStore;
  let fixture: ComponentFixture<RentalTopTenFilmsByStore>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [RentalTopTenFilmsByStore]
    })
    .compileComponents();

    fixture = TestBed.createComponent(RentalTopTenFilmsByStore);
    component = fixture.componentInstance;
    await fixture.whenStable();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
