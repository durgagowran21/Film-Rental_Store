// import { Component } from '@angular/core';
// import { FormsModule } from '@angular/forms';
// import { CommonModule } from '@angular/common';
// import { PaymentService } from '../../services/payment';
// import { PaymentDTO } from '../../models/payment';

// @Component({
//   selector: 'app-payment-form',
//   standalone: true,
//   imports: [CommonModule, FormsModule],
//   template: `
//     <h2>Add Payment</h2>
//     <form (ngSubmit)="submit()">
//       <label>Payment ID: <input type="number" [(ngModel)]="model.paymentId" name="paymentId" required></label><br>
//       <label>Customer ID: <input type="number" [(ngModel)]="model.customerId" name="customerId" required></label><br>
//       <label>Staff ID: <input type="number" [(ngModel)]="model.staffId" name="staffId" required></label><br>
//       <label>Rental ID: <input type="number" [(ngModel)]="model.rentalId" name="rentalId"></label><br>
//       <label>Amount: <input type="number" step="0.01" [(ngModel)]="model.amount" name="amount" required></label><br>
//       <button type="submit">Submit</button>
//     </form>
//     <p *ngIf="message">{{ message }}</p>
//     <p *ngIf="error" style="color:red">{{ error }}</p>
//   `
// })
// export class PaymentFormComponent {
//   model: PaymentDTO = { paymentId: 0, customerId: 0, staffId: 0, amount: 0 };
//   message = ''; error = '';

//   constructor(private payment: PaymentService) {}

//   submit() {
//     this.message = ''; this.error = '';
//     this.payment.addPayment(this.model).subscribe({
//       next: (msg) => this.message = msg,
//       error: (err) => this.error = err?.error ?? 'Failed to add payment'
//     });
//   }
// }


import { Component } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { PaymentDTO } from '../../entity/payment';
import { PaymentService } from '../../Service/payment';
import { RouterOutlet } from '@angular/router';

@Component({
  selector: 'app-payment-form',
  standalone: true,
  imports: [CommonModule, FormsModule,RouterOutlet],
  templateUrl: './payment-form.html',
  // Optional: add styles in a separate file
  // styleUrls: ['./payment-form.component.css']
})
export class PaymentFormComponent {
  model: PaymentDTO = { paymentId: 0, customerId: 0, staffId: 0, amount: 0 };
  message = '';
  error = '';

  constructor(private payment: PaymentService) {}

  submit() {
    this.message = '';
    this.error = '';
    this.payment.addPayment(this.model).subscribe({
      next: (msg) => this.message = msg,
      error: (err) => this.error = err?.error ?? 'Failed to add payment'
    });
  }
}
