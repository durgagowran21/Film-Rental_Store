import { ComponentFixture, TestBed } from '@angular/core/testing';

import { RentalsByCustomer } from './rentals-by-customer';

describe('RentalsByCustomer', () => {
  let component: RentalsByCustomer;
  let fixture: ComponentFixture<RentalsByCustomer>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [RentalsByCustomer]
    })
    .compileComponents();

    fixture = TestBed.createComponent(RentalsByCustomer);
    component = fixture.componentInstance;
    await fixture.whenStable();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
