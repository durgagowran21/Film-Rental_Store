import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { RentalDto } from '../../entity/rental';
import { RentalService } from '../../Service/rental';
import { RouterOutlet } from '@angular/router';

@Component({
  selector: 'app-rentals-by-customer',
  standalone: true,
  imports: [CommonModule, FormsModule,RouterOutlet],
  templateUrl: './rentals-by-customer.html',
  // styleUrls: ['./rentals-by-customer.component.css'] // optional
})
export class RentalsByCustomerComponent {
  customerId?: number;
  rentals: RentalDto[] = [];
  error = '';
  loading = false;

  constructor(private rental: RentalService) {}

  load() {
    if (!this.customerId) {
      this.error = 'Enter customerId';
      return;
    }
    this.error = '';
    this.loading = true;

    this.rental.getRentalsByCustomer(this.customerId).subscribe({
      next: (list) => {
        this.rentals = list ?? [];
        this.loading = false;
      },
      error: (err) => {
        this.error = err?.error ?? 'Failed to fetch rentals';
        this.loading = false;
      }
    });
  }
}
