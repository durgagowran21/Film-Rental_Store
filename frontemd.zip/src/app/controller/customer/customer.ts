 
// src/app/components/customer.component/customer.component.ts
import { Component, computed, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule, FormBuilder, Validators, FormGroup } from '@angular/forms';
import { CustomerDto, Store } from '../../entity/customer-entity';
import { CustomerService } from '../../Service/cust-serv';
import { Router } from 'express';
import { RouterModule } from '@angular/router';
import { ActorListComponent } from '../actor-list/actor-list';
 
type SearchKind = 'lastname' | 'firstname' | 'email' | 'phone' | 'city' | 'country' | 'active' | 'inactive';
type Tab = 'create' | 'search' | 'update';
 
@Component({
  selector: 'app-customer',                // <-- matches <app-customer> in app.html
  standalone: true,
  imports: [CommonModule, FormsModule, ReactiveFormsModule,RouterModule,ActorListComponent],
  templateUrl: './customer.html',
  styleUrls: ['./customer.css']
})
export class Customer {
  // Tabs
  currentTab: Tab = 'create';
  router: any;
  setTab(tab: Tab) { this.currentTab = tab; }
 
  // UI state
  loading = signal(false);
  error = signal<string | null>(null);
  notice = signal<string | null>(null);
 
  // Results
  customers = signal<CustomerDto[]>([]);
  selected?: CustomerDto;
  ActorListComponent=signal<ActorListComponent[]>([]);
  selectedActor?: ActorListComponent;
  // Search
  searchKind: SearchKind = 'lastname';
  searchValue = '';
 
  // Forms
  createForm!: FormGroup;
  updateNameForm!: FormGroup;
  updateEmailForm!: FormGroup;
  updatePhoneForm!: FormGroup;
  assignAddressForm!: FormGroup;
  assignStoreForm!: FormGroup;
 
  total = computed(() => this.customers().length);
 
  constructor(private fb: FormBuilder, private api: CustomerService) {
    // Initialize forms
    this.createForm = this.fb.group({
      firstName: ['', [Validators.required, Validators.maxLength(45)]],
      lastName: ['', [Validators.required, Validators.maxLength(45)]],
      email: ['', [Validators.email, Validators.maxLength(50)]],
      active: [true],
      addressId: [0, [Validators.required, Validators.min(1)]],
      storeId: [0, [Validators.required, Validators.min(1)]],
    });
 
    this.updateNameForm = this.fb.group({
      id: [null, [Validators.required]],
      firstName: [''],
      lastName: [''],
    });
 
    this.updateEmailForm = this.fb.group({
      id: [null, [Validators.required]],
      email: ['', [Validators.email]],
    });
 
    this.updatePhoneForm = this.fb.group({
      id: [null, [Validators.required]],
      phone: [''],
    });
 
    this.assignAddressForm = this.fb.group({
      customerId: [null, [Validators.required]],
      addressId: [null, [Validators.required, Validators.min(1)]],
    });
 
    this.assignStoreForm = this.fb.group({
      customerId: [null, [Validators.required]],
      storeId: [null, [Validators.required, Validators.min(1)]],
    });
  }
 
  // --- SEARCH ---
  search(): void {
    this.error.set(null);
    this.loading.set(true);
    const kind = this.searchKind;
 
    let req$;
    switch (kind) {
      case 'lastname': req$ = this.api.getByLastName(this.searchValue.trim()); break;
      case 'firstname': req$ = this.api.getByFirstName(this.searchValue.trim()); break;
      case 'email':     req$ = this.api.getByEmail(this.searchValue.trim()); break;
      case 'phone':     req$ = this.api.getByPhone(this.searchValue.trim()); break;
      case 'city':      req$ = this.api.getByCity(this.searchValue.trim()); break;
      case 'country':   req$ = this.api.getByCountry(this.searchValue.trim()); break;
      case 'active':    req$ = this.api.getActive(); break;
      case 'inactive':  req$ = this.api.getInactive(); break;
      default:          req$ = this.api.getActive(); break;
    }
 
    req$.subscribe({
      next: res => { this.customers.set(res || []); this.loading.set(false); this.notice.set(`Found ${res?.length ?? 0} record(s).`); },
      error: err => { this.loading.set(false); this.error.set(this.extractErr(err)); }
    });
  }
 
  // --- CREATE ---
  create(): void {
    if (this.createForm.invalid) return this.touchAll(this.createForm);
    this.loading.set(true);
    const payload = this.createForm.value as CustomerDto;
    this.api.createCustomer(payload).subscribe({
      next: msg => {
        this.notice.set(msg || 'Customer created');
        this.createForm.reset({ active: true });
        this.loading.set(false);
        // this.setTab('search');
      },
      error: err => { this.loading.set(false); this.error.set(this.extractErr(err)); }
    });
  }
 
  // --- QUICK UPDATES ---
  updateFirstName(): void {
    const { id, firstName } = this.updateNameForm.value;
    if (!id || !firstName) return this.touchAll(this.updateNameForm);
    this.loading.set(true);
    this.api.updateFirstName(Number(id), firstName!).subscribe({
      next: c => { this.replace(c); this.notice.set('First name updated'); this.loading.set(false); },
      error: err => { this.loading.set(false); this.error.set(this.extractErr(err)); }
    });
  }
 
  updateLastName(): void {
    const { id, lastName } = this.updateNameForm.value;
    if (!id || !lastName) return this.touchAll(this.updateNameForm);
    this.loading.set(true);
    this.api.updateLastName(Number(id), lastName!).subscribe({
      next: c => { this.replace(c); this.notice.set('Last name updated'); this.loading.set(false); },
      error: err => { this.loading.set(false); this.error.set(this.extractErr(err)); }
    });
  }
 
  updateEmail(): void {
    const { id, email } = this.updateEmailForm.value;
    if (!id || !email) return this.touchAll(this.updateEmailForm);
    this.loading.set(true);
    this.api.updateEmail(Number(id), email!).subscribe({
      next: c => { this.replace(c); this.notice.set('Email updated'); this.loading.set(false); },
      error: err => { this.loading.set(false); this.error.set(this.extractErr(err)); }
    });
  }
 
  updatePhone(): void {
    const { id, phone } = this.updatePhoneForm.value;
    if (!id || !phone) return this.touchAll(this.updatePhoneForm);
    this.loading.set(true);
    this.api.updatePhone(Number(id), phone!).subscribe({
      next: c => { this.replace(c); this.notice.set('Phone updated'); this.loading.set(false); },
      error: err => { this.loading.set(false); this.error.set(this.extractErr(err)); }
    });
  }
 
  // --- ASSIGNMENTS ---
  assignAddress(): void {
    const { customerId, addressId } = this.assignAddressForm.value;
    if (!customerId || !addressId) return this.touchAll(this.assignAddressForm);
    this.loading.set(true);
    this.api.assignAddress(Number(customerId), Number(addressId)).subscribe({
      next: c => { this.replace(c); this.notice.set('Address assigned'); this.loading.set(false); },
      error: err => { this.loading.set(false); this.error.set(this.extractErr(err)); }
    });
  }
 
  assignStore(): void {
    const { customerId, storeId } = this.assignStoreForm.value;
    if (!customerId || !storeId) return this.touchAll(this.assignStoreForm);
    this.loading.set(true);
    const store: Store = { storeId: Number(storeId) };
    this.api.assignStore(Number(customerId), store).subscribe({
      next: c => { this.replace(c); this.notice.set('Store assigned'); this.loading.set(false); },
      error: err => { this.loading.set(false); this.error.set(this.extractErr(err)); }
    });
  }
 
  // --- helpers ---
  choose(c: CustomerDto) {
    this.selected = c;
    // Pre-fill IDs across forms
    this.updateNameForm.patchValue({ id: c.customerId });
    this.updateEmailForm.patchValue({ id: c.customerId });
    this.updatePhoneForm.patchValue({ id: c.customerId });
    this.assignAddressForm.patchValue({ customerId: c.customerId });
    this.assignStoreForm.patchValue({ customerId: c.customerId });
  }
 
  clearSelection() { this.selected = undefined; }
 
  private replace(updated: CustomerDto) {
    const list = this.customers();
    const idx = list.findIndex(x => x.customerId === updated.customerId);
    if (idx >= 0) { list[idx] = updated; this.customers.set([...list]); }
  }
 
  private touchAll(group: any) {
    Object.values(group.controls).forEach((c: any) => c.markAsTouched());
  }
 
  private extractErr(err: any): string {
    if (err?.error?.message) return err.error.message;
    if (typeof err?.error === 'string') return err.error;
    return 'Something went wrong. Please try again.';
  }

  goToActorByname(firstName: String): void {
 this.router.navigate(['/actorlist', searchByFirstName(firstName)]);
}
 goToActorBylastname(Lastname: String): void {
 this.router.navigate(['/actorlist', searchByFirstName(Lastname)]);
}


  //const target= this.role
      
//  const target = this.role === 'staff' ? '/staff' : '/customer';
//     this.router.navigate([target]);
//   }
//   GoToRole():void{
//     const target = this.role === 'staff' ? '/staff' : '/customer';
//     this.router.navigate([target]);
//   }
//everything is visble except customer: store,payment, rental,return,address,film,category,language,actors.
}
 
 

function searchByFirstName(firstName: String): any {
  throw new Error('Function not implemented.');
}
// goToFilmEdit(): void {
//   this.router.navigate(['/film/edit']);
// }

// // If you want to edit a specific actor/film by id:
// goToFilmEditById(id: number): void {
//   this.router.navigate(['/film/edit', id]);
// }
