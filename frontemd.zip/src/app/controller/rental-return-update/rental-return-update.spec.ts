import { ComponentFixture, TestBed } from '@angular/core/testing';

import { RentalReturnUpdate } from './rental-return-update';

describe('RentalReturnUpdate', () => {
  let component: RentalReturnUpdate;
  let fixture: ComponentFixture<RentalReturnUpdate>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [RentalReturnUpdate]
    })
    .compileComponents();

    fixture = TestBed.createComponent(RentalReturnUpdate);
    component = fixture.componentInstance;
    await fixture.whenStable();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
