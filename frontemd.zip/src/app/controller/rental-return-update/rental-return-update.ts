
import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { RentalDto } from '../../entity/rental';
import { RentalService } from '../../Service/rental';
import { RouterOutlet } from '@angular/router';

@Component({
  selector: 'app-rental-return-update',
  standalone: true,
  imports: [CommonModule, FormsModule,RouterOutlet],
  templateUrl: './rental-return-update.html',
  // styleUrls: ['./rental-return-update.component.css'] // optional
})
export class RentalReturnUpdateComponent {
  rentalId?: number;
  returnLocal?: string; // "YYYY-MM-DDTHH:mm" from <input type="datetime-local">
  updated?: RentalDto;
  error = '';

  constructor(private rental: RentalService) {}

  update() {
    if (!this.rentalId || !this.returnLocal) {
      this.error = 'Enter rentalId and return date/time';
      return;
    }
    this.error = '';

    // Normalize to "YYYY-MM-DDTHH:mm:ss" (LocalDateTime-friendly)
    // datetime-local gives "YYYY-MM-DDTHH:mm"; add ":00" seconds
    const isoLocal = this.returnLocal.length === 16
      ? `${this.returnLocal}:00`
      : this.returnLocal;

    // ✅ Send plain string (do NOT JSON.stringify)
    this.rental.updateReturnDate(this.rentalId, isoLocal).subscribe({
      next: (dto) => this.updated = dto,
      error: (err) => this.error = err?.error ?? 'Failed to update return date'
    });
  }
}
