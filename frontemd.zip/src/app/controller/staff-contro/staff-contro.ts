import { Component } from '@angular/core';

import { FormBuilder, Validators } from '@angular/forms';
import { ActivatedRoute, RouterModule, RouterOutlet } from '@angular/router';
import { StaffServ } from '../../Service/staff-serv';
import { StaffEntity } from '../../entity/staff-entity';
import { CommonModule, JsonPipe } from '@angular/common';
import { NgModule } from '@angular/core';
import { ReactiveFormsModule } from '@angular/forms';  // Add this import
import { HttpClient } from '@angular/common/http';
//import { form } from '@angular/forms/signals';



@Component({

  selector: 'app-staff-contro',
  standalone: true,
  imports: [JsonPipe, CommonModule, ReactiveFormsModule,RouterOutlet, RouterModule],
  templateUrl: './staff-contro.html',
  styleUrls: ['./staff-contro.css'],
})
export class StaffContro {

// id:Number
 id: number;
  staff?: StaffEntity;
  error?: string;
  form;
loading: any;
results: any;
  


   constructor(private fb: FormBuilder, private route: ActivatedRoute, private staffServ: StaffServ) {
    this.id = Number(this.route.snapshot.paramMap.get('id'));
    this.form = this.fb.nonNullable.group({
    firstName: ['', Validators.required],
    lastName: ['', Validators.required],
    email: ['', [Validators.required, Validators.email]],
    phone: ['', [Validators.required, Validators.pattern(/^[0-9]{10}$/)]],
    storeId: [0, Validators.required],
    addressId: [0, Validators.required],
  });
  }
 
  updateFirstName(): void {
    const firstName = this.form.controls.firstName.value;
    this.staffServ.updateFirstName(this.id, { firstName }).subscribe({
      next: s => { this.staff = s; alert('First name updated'); },
 error: e => this.error = e?.message ?? 'Update failed'
    });
  }

 updateLastName(): void {
    const lastName = this.form.controls.lastName.value;
    this.staffServ.updateLastName(this.id, { lastName }).subscribe({
      next: s => { this.staff = s; alert('Last name updated'); },
      error: e => this.error = e?.message ?? 'Update failed'
    });
  }
  
updateEmail(): void {
    const email = this.form.controls.email.value;
    this.staffServ.updateEmail(this.id, { email }).subscribe({
      next: s => { this.staff = s; alert('Email updated'); },
      error: e => this.error = e?.message ?? 'Update failed'
    });
  }
  updatePhone(): void {
    const phone = this.form.controls.phone.value;
    this.staffServ.updatePhone(this.id, { phone }).subscribe({
      next: s => { this.staff = s; alert('Phone updated'); },
      error: e => this.error = e?.message ?? 'Update failed'
    });
  }
  
updateStore(): void {
    const storeId = Number(this.form.controls.storeId.value);
    this.staffServ.assignStore(this.id, { storeId }).subscribe({
      next: s => { this.staff = s; alert('Store updated'); },
      error: e => this.error = e?.message ?? 'Update failed'
    });
  }

 assignAddress(): void {
    const addressId = Number(this.form.controls.addressId.value);
    this.staffServ.assignAddress(this.id, { addressId }).subscribe({
      next: s => { this.staff = s; alert('Address assigned'); },
      error: e => this.error = e?.message ?? 'Assign failed'
    });
  }

  
//rentals,staff,customer,payment,address,store,film,actor,language,category.
}
