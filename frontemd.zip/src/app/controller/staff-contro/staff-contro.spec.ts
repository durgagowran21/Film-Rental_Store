import { ComponentFixture, TestBed } from '@angular/core/testing';

import { StaffContro } from './staff-contro';

describe('StaffContro', () => {
  let component: StaffContro;
  let fixture: ComponentFixture<StaffContro>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [StaffContro]
    })
    .compileComponents();

    fixture = TestBed.createComponent(StaffContro);
    component = fixture.componentInstance;
    await fixture.whenStable();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
