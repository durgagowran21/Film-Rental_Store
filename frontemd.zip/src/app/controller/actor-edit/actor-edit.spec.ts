import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ActorEdit } from './actor-edit';

describe('ActorEdit', () => {
  let component: ActorEdit;
  let fixture: ComponentFixture<ActorEdit>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [ActorEdit]
    })
    .compileComponents();

    fixture = TestBed.createComponent(ActorEdit);
    component = fixture.componentInstance;
    await fixture.whenStable();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
