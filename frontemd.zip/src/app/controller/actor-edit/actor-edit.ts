
import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { ActorDto } from '../../entity/actor-entity';
import { ActorServ as ActorService } from '../../Service/actor-serv';
import { Router } from '@angular/router';

@Component({
  selector: 'app-actor-edit',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './actor-edit.html',
  styleUrls: ['./actor-edit.css']
})
export class ActorEditComponent {
  newActor: any = { id: 0, firstName: '', lastName: '' };
  updateId!: number;
  firstName = '';
  lastName = '';
  saving = false;

  constructor(private svc: ActorService,public route: Router) {}

  create() {
    const { id, firstName, lastName } = this.newActor;
    if (!id || !firstName.trim() || !lastName.trim()) {
      return alert('Provide id, firstName, lastName');
    }
    this.saving = true;
    this.svc.create({ id, firstName: firstName.trim(), lastName: lastName.trim() })
      .subscribe({
        next: msg => { alert(msg); this.saving = false; },
        error: err => { alert('Create failed: ' + err.message); this.saving = false; }
      });
  }

  updateFirst() {
    if (!this.updateId || !this.firstName.trim()) return alert('Provide actor id and new first name');
    this.svc.updateFirstName(this.updateId, this.firstName.trim()).subscribe({
      next: () => alert('First name updated'),
      error: err => alert('Update failed: ' + err.message)
    });
  }

  updateLast() {
    if (!this.updateId || !this.lastName.trim()) return alert('Provide actor id and new last name');
    this.svc.updateLastName(this.updateId, this.lastName.trim()).subscribe({
      next: () => alert('Last name updated'),
      error: err => alert('Update failed: ' + err.message)
    });
  }
}
