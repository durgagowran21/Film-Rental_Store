
import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RentalDto } from '../../entity/rental';
import { RentalService } from '../../Service/rental';
import { RouterOutlet } from '@angular/router';


@Component({
  selector: 'app-top-ten-films',
  standalone: true,
  imports: [CommonModule,RouterOutlet],
  templateUrl: './rental-top-ten-films.html',
  // styleUrls: ['./top-ten-films.component.css'] // optional
})
export class TopTenFilmsComponent {
  rentals: RentalDto[] = [];
  loading = false;
  error = '';

  constructor(private svc: RentalService) {}

  load() {
    this.loading = true;
    this.error = '';
    this.svc.getTopTenFilms().subscribe({
      next: (list) => {
        this.rentals = list ?? [];
        this.loading = false;
      },
      error: (err) => {
        this.error = err?.message ?? 'Failed to load top ten films';
        this.loading = false;
      }
    });
  }
}
