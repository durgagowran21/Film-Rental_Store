import { ComponentFixture, TestBed } from '@angular/core/testing';

import { RentalTopTenFilms } from './rental-top-ten-films';

describe('RentalTopTenFilms', () => {
  let component: RentalTopTenFilms;
  let fixture: ComponentFixture<RentalTopTenFilms>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [RentalTopTenFilms]
    })
    .compileComponents();

    fixture = TestBed.createComponent(RentalTopTenFilms);
    component = fixture.componentInstance;
    await fixture.whenStable();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
