import { Component } from '@angular/core';
import { FormBuilder, FormGroup, ReactiveFormsModule, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { CategoryServ } from '../../Service/category-serv';
import { Category } from '../../entity/category-entity';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-category',
  standalone: true,
  imports: [ReactiveFormsModule, CommonModule],
  templateUrl: './category.html',
  styleUrl: './category.css'
})
export class CategoryComponent {
  categoryForm: FormGroup;
  message: string = '';

  constructor(
    private fb: FormBuilder,
    private categoryServ: CategoryServ,
    private router: Router
  ) {
    this.categoryForm = this.fb.group({
      name: ['', Validators.required]
    });
  }

  onSubmit() {
    if (this.categoryForm.valid) {
      const category: Category = this.categoryForm.value;
      this.categoryServ.createCategory(category).subscribe({
        next: (response) => {
          this.message = response;
          this.categoryForm.reset();
        },
        error: (err) => {
          this.message = 'Error creating category: ' + err.message;
        }
      });
    }
  }

  navigateTo(path: string) {
    this.router.navigate([path]);
  }
}