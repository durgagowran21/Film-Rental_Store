import { Component, inject, signal, TrackByFunction } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { RouterModule, ActivatedRoute, Router } from '@angular/router';
import { StoreServ } from '../../Service/store-serv';
import { StoreModel, StoreDto, StaffDTO, CustomerDto } from '../../entity/store-entity';


type GetMode = 'all' | 'city' | 'country' | 'phone';

@Component({
  selector: 'app-store-contro',
  standalone: true,
  imports: [CommonModule, FormsModule, RouterModule],
  templateUrl: './store-contro.html',
  styleUrls: ['./store-contro.css']
})
export class StoreContro {
  private api = inject(StoreServ);
  private route = inject(ActivatedRoute);
  private router = inject(Router);

  // LIST
  stores = signal<StoreModel[]>([]);
  loadError = signal<string>('');

  // GET selector + search inputs
  selectedGet = signal<GetMode>('all');
  city = signal<string>('');
  country = signal<string>('');
  phone = signal<string>('');
  byCity = signal<StoreDto[]>([]);
  byCountry = signal<StoreDto[]>([]); // By Country uses StoreDto to show storeId/addressID/lastUpdate
  byPhone = signal<StoreDto | null>(null);
  searchErr = signal<string>('');

  // CREATE
  addressID = signal<number>(0);
  createMsg = signal<string>('');
  createErr = signal<string>('');

  // ASSIGN ADDRESS (PUT)
  assignStoreId = signal<number>(0);
  assignAddressId = signal<number>(0);
  assignMsg = signal<string>('');
  assignErr = signal<string>('');

  // UPDATE PHONE (PUT)
  storeIdForPhone = signal<number | null>(null);
  newPhone = signal<string>('');
  updateMsg = signal<string>('');
  updateErr = signal<string>('');

  // DETAILS (per selected card)
  currentStoreId = signal<number | null>(null);
  staff = signal<StaffDTO[]>([]);
  customers = signal<CustomerDto[]>([]);
  detailErr = signal<string>('');
  loadingStaff = signal<boolean>(false);
  loadingCustomers = signal<boolean>(false);

  ngOnInit() {
    // Optional: support deep-linking (/stores/:id); will render data inside the matching card if present
    this.route.paramMap.subscribe(pm => {
      const idParam = pm.get('id');
      if (idParam) {
        const id = Number(idParam);
        this.showDetails(id);
      }
    });
  }

  // ---------- proxies for [(ngModel)] ----------
  get selectedGetValue() { return this.selectedGet(); }
  set selectedGetValue(v: GetMode) { this.selectedGet.set(v as GetMode); }

  get cityValue() { return this.city(); }
  set cityValue(v: string) { this.city.set(v); }

  get countryValue() { return this.country(); }
  set countryValue(v: string) { this.country.set(v); }

  get phoneValue() { return this.phone(); }
  set phoneValue(v: string) { this.phone.set(v); }

  get addressIDValue() { return this.addressID(); }
  set addressIDValue(v: number) { this.addressID.set(Number(v)); }

  get assignStoreIdValue() { return this.assignStoreId(); }
  set assignStoreIdValue(v: number) { this.assignStoreId.set(Number(v)); }

  get assignAddressIdValue() { return this.assignAddressId(); }
  set assignAddressIdValue(v: number) { this.assignAddressId.set(Number(v)); }

  get storeIdForPhoneValue() { return this.storeIdForPhone(); }
  set storeIdForPhoneValue(v: number | null) { this.storeIdForPhone.set(v ? Number(v) : null); }

  get newPhoneValue() { return this.newPhone(); }
  set newPhoneValue(v: string) { this.newPhone.set(v); }

  // -------------------- Helpers --------------------
  private loadStores() {
    this.api.getAllStores().subscribe({
      next: (list) => this.stores.set(list ?? []),
      error: () => this.loadError.set('Failed to load stores')
    });
  }

  reloadStores() {
    this.currentStoreId.set(null);
    this.resetDetails();
    this.loadStores();
  }

  clearGetResults() {
    this.stores.set([]);
    this.byCity.set([]);
    this.byCountry.set([]);
    this.byPhone.set(null);
    this.loadError.set('');
    this.searchErr.set('');
  }

  fetchSelected() {
    this.clearGetResults();
    switch (this.selectedGet()) {
      case 'all': this.loadStores(); break;
      case 'city': this.searchByCity(); break;
      case 'country': this.searchByCountry(); break;
      case 'phone': this.searchByPhone(); break;
    }
  }

  private resetDetails() {
    this.staff.set([]);
    this.customers.set([]);
    this.detailErr.set('');
    this.loadingStaff.set(false);
    this.loadingCustomers.set(false);
  }

  // ✅ Show details inside the clicked accordion card
  showDetails(id: number) {
    if (!id) return;
    // Toggle: collapse if the same card is clicked
    if (this.currentStoreId() === id) {
      this.currentStoreId.set(null);
      this.resetDetails();
      return;
    }
    this.currentStoreId.set(id);
    this.resetDetails();
    this.loadDetail(id);
    // Auto-open the <details> card so the inline panel is visible immediately
    setTimeout(() => {
      const el = document.getElementById(`store-${id}`) as HTMLDetailsElement | null;
      if (el && !el.open) el.open = true;
    }, 0);
  }

  // -------------------- Actions --------------------
  createStore() {
    const addr = this.addressID();
    if (!addr || addr <= 0) {
      this.createErr.set('Address ID is required');
      return;
    }
    this.api.addStore({ addressID: addr }).subscribe({
      next: (store) => {
        this.createMsg.set(`Created Store #${store.storeId}`);
        this.createErr.set('');
      },
      error: () => this.createErr.set('Failed to create store')
    });
  }

  assignAddress() {
    const sId = this.assignStoreId();
    const aId = this.assignAddressId();
    if (!sId || !aId) {
      this.assignErr.set('Both Store ID and Address ID are required');
      return;
    }
    this.api.assignAddressToStore(sId, aId).subscribe({
      next: () => {
        this.assignMsg.set(`Assigned Address ID ${aId} to Store #${sId}`);
        this.assignErr.set('');
      },
      error: () => this.assignErr.set('Failed to assign address')
    });
  }

  searchByCity() {
    const c = this.city().trim();
    if (!c) {
      this.searchErr.set('City is required');
      return;
    }
    this.api.getStoresByCity(c).subscribe({
      next: (res) => { this.byCity.set(res ?? []); this.searchErr.set(''); },
      error: () => this.searchErr.set('No stores found in city or server error')
    });
  }

  searchByCountry() {
    const c = this.country().trim();
    if (!c) {
      this.searchErr.set('Country is required');
      return;
    }
    this.api.getStoresByCountry(c).subscribe({
      next: (res) => { this.byCountry.set(res ?? []); this.searchErr.set(''); },
      error: () => this.searchErr.set('No stores found in country or server error')
    });
  }

  searchByPhone() {
    const p = this.phone().trim();
    if (!p) {
      this.searchErr.set('Phone is required');
      return;
    }
    this.api.getStoreByPhone(p).subscribe({
      next: (res) => { this.byPhone.set(res ?? null); this.searchErr.set(''); },
      error: () => this.searchErr.set('No store found for phone or server error')
    });
  }

  updatePhone() {
    const sId = this.storeIdForPhone();
    const np = this.newPhone().trim();
    if (!sId || !np) {
      this.updateErr.set('Store ID and New Phone are required');
      return;
    }
    this.api.updateStorePhoneNumber(sId, np).subscribe({
      next: (msg) => { this.updateMsg.set(msg ?? 'Updated'); this.updateErr.set(''); },
      error: () => this.updateErr.set('Failed to update phone')
    });
  }

  // -------------------- Detail loader --------------------
  private loadDetail(id: number) {
    this.loadingStaff.set(true);
    this.loadingCustomers.set(true);

    this.api.getStaffByStoreId(id).subscribe({
      next: (res) => this.staff.set(res ?? []),
      error: () => this.detailErr.set('Failed to load staff for store ' + id),
      complete: () => this.loadingStaff.set(false)
    });

    this.api.getCustomersByStoreId(id).subscribe({
      next: (res) => this.customers.set(res ?? []),
      error: () => this.detailErr.set('Failed to load customers for store ' + id),
      complete: () => this.loadingCustomers.set(false)
    });
  }

  // -------------------- trackBy functions --------------------
  trackByStoreId(index: number, item: StoreModel): number | string {
    return item.storeId;
  }

  trackByStaffId: TrackByFunction<StaffDTO> = (_i, st) => st.staffId;
  trackByCustomerId: TrackByFunction<CustomerDto> = (_i, c) => c.customerId;
  trackByStoreDtoId: TrackByFunction<StoreDto> = (_i, s) => s.storeId;
}

