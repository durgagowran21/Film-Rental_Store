import { ComponentFixture, TestBed } from '@angular/core/testing';

import { StoreContro } from './store-contro';

describe('StoreContro', () => {
  let component: StoreContro;
  let fixture: ComponentFixture<StoreContro>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [StoreContro]
    })
    .compileComponents();

    fixture = TestBed.createComponent(StoreContro);
    component = fixture.componentInstance;
    await fixture.whenStable();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
