import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { HttpClient } from '@angular/common/http';
import { RouterOutlet } from '@angular/router';

@Component({
  standalone: true,
  selector: 'payment-revenue',
  imports: [CommonModule,RouterOutlet],
  templateUrl: './payment-revenue.html',
  styleUrls: ['./payment-revenue.css']
})
export class PaymentRevenueComponent {
  // Adjust the type of `data` to match your API
  data: any = {};
  loading = false;
  error: string | null = null;

  // ✅ Expose Object.keys to the template
  objectKeys = Object.keys;

  constructor(private http: HttpClient) {}

  ngOnInit(): void {
    // Optional: auto-load on init
    // this.fetchRevenue();
  }

  fetchRevenue(): void {
    this.loading = true;
    this.error = null;
    // TODO: replace with your actual API URL, e.g., `${environment.apiBase}/payment/revenue`
    this.http.get<any>('/api/payment/revenue').subscribe({
      next: (res) => {
        this.data = res ?? {};
        this.loading = false;
      },
      error: (err) => {
        this.error = 'Failed to load revenue';
        console.error(err);
        this.loading = false;
      }
    });
  }
}
