

import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';

 // <-- ensure path matches
import { ReactiveFormsModule, FormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { HasRoleDirective } from '../../shared/directives/has-role';
import { ActorDto, FilmDto, Language } from '../../entity/film.model';
import { FilmService } from '../../Service/film';
import { LanguageService } from '../../Service/language';
import { ActorService } from '../../Service/actor';
import { CategoryService } from '../../Service/category';
import { MatSnackBar } from '@angular/material/snack-bar';
import { RoleService } from '../../core/role.service';
import { RouterOutlet } from '@angular/router';






@Component({
  selector: 'app-film-manage',
  standalone: true,
  templateUrl: './film-manage.html',
  styleUrls: ['./film-manage.scss'],
  
imports: [
    CommonModule, ReactiveFormsModule, FormsModule, HasRoleDirective,RouterOutlet // <-- add the directive here
    //HasAnyRoleDirective 
  ]

})
export class FilmManageComponent implements OnInit {
  languages: Language[] = [];
  actorSearchResults: ActorDto[] = [];

  // ✅ Declare first; initialize later in ngOnInit
  createForm!: FormGroup;
  updateForm!: FormGroup;
  assignActorsForm!: FormGroup;
  categoryForm!: FormGroup;

  constructor(
    private fb: FormBuilder,
    private filmSvc: FilmService,
    private langSvc: LanguageService,
    private actorSvc: ActorService,
    private categorySvc: CategoryService,
    private snack: MatSnackBar,
    public roleSvc: RoleService
  ) {}

  ngOnInit(): void {
    // ✅ Safe: fb is injected before this runs
    this.createForm = this.fb.group({
      title: ['', Validators.required],
      description: [''],
      releaseYear: [null],
      languageId: [null, Validators.required],
      rentalDuration: [null],
      rentalRate: [null],
      length: [null],
      replacementCost: [null],
      rating: [null],
      specialFeatures: ['']
    });

    this.updateForm = this.fb.group({
      id: [null, Validators.required],
      title: [''],
      releaseYear: [null],
      rentalDuration: [null],
      rentalRate: [null],
      rating: [null],
      languageId: [null]
    });

    this.assignActorsForm = this.fb.group({
      filmId: [null, Validators.required],
      actorIdsCsv: ['']
    });

    this.categoryForm = this.fb.group({
      filmId: [null, Validators.required],
      categoryId: [null, Validators.required],
      //categoryNameForNew: ['']
    });

    this.loadLanguages();
  }

  loadLanguages() {
    this.langSvc.getAll().subscribe({
      next: res => this.languages = res,
      error: () => this.snack.open('Failed to load languages', 'OK', { duration: 2500 })
    });
  }

  // Create film
  createFilm() {
    if (!this.createForm.valid) return this.toast('Please fill required fields');
    const payload: FilmDto = this.createForm.value as any;
    this.filmSvc.addFilm(payload).subscribe({
      next: msg => this.toast(msg || 'Created'),
      error: err => this.toast(err?.error?.message || 'Create failed')
    });
  }

  // Update fields
  async updateFields() {
    const v = this.updateForm.value;
    if (!v.id) return this.toast('Film ID required');

    try {
      if (v.title && v.title.trim()) await this.filmSvc.updateTitle(v.id!, v.title.trim()).toPromise();
      if (v.releaseYear !== null && v.releaseYear !== undefined) await this.filmSvc.updateReleaseYear(v.id!, Number(v.releaseYear)).toPromise();
      if (v.rentalDuration !== null && v.rentalDuration !== undefined) await this.filmSvc.updateRentalDuration(v.id!, Number(v.rentalDuration)).toPromise();
      if (v.rentalRate !== null && v.rentalRate !== undefined) await this.filmSvc.updateRentalRate(v.id!, Number(v.rentalRate)).toPromise();
      if (v.rating !== null && v.rating !== undefined) await this.filmSvc.updateRating(v.id!, Number(v.rating)).toPromise();
      if (v.languageId !== null && v.languageId !== undefined) await this.filmSvc.updateLanguage(v.id!, Number(v.languageId)).toPromise();
      this.toast('Updated successfully');
    } catch (err: any) {
      this.toast(err?.error?.message || 'Update failed');
    }
  }

  // Assign actors
  // searchActorsByLastName(ln: string) {
  //   if (!ln?.trim()) return;
  //   this.actorSvc.getByLastName(ln.trim()).subscribe({
  //     next: res => this.actorSearchResults = res,
  //     error: err => this.toast(err?.error?.message || 'Search failed')
  //   });
  // }

  // searchActorsByFirstName(fn: string) {
  //   if (!fn?.trim()) return;
  //   this.actorSvc.getByFirstName(fn.trim()).subscribe({
  //     next: res => this.actorSearchResults = res,
  //     error: err => this.toast(err?.error?.message || 'Search failed')
  //   });
  // }

  assignActors() {
    const filmId = Number(this.assignActorsForm.value.filmId);
    const idsCsv = this.assignActorsForm.value.actorIdsCsv || '';
    
const ids = idsCsv
  .split(',')
  .map((x: string) => Number(x.trim()))
  .filter((x: number) => !isNaN(x));

    //const ids = idsCsv.split(',').map(x => Number(x.trim())).filter(x => !isNaN(x));
    
    if (!filmId || ids.length === 0) return this.toast('Enter FilmId and actor IDs');

    this.filmSvc.assignActorsToFilm(filmId, ids).subscribe({
      next: msg => this.toast(msg || 'Actors assigned'),
      error: err => this.toast(err?.error?.message || 'Assign failed')
    });
  }

  // // Category
  // createCategoryIfNeeded() {
  //   const name = this.categoryForm.value.categoryNameForNew?.trim();
  //   if (!name) return;
  //   const payload: Category = { categoryId: 0 as any, name };
  //   this.categorySvc.createCategory(payload).subscribe({
  //     next: msg => this.toast('Category created'),
  //     error: err => this.toast(err?.error?.message || 'Category creation failed')
  //   });
  // }

  updateCategory() {
    const filmId = Number(this.categoryForm.value.filmId);
    const categoryId = Number(this.categoryForm.value.categoryId);
    if (!filmId || !categoryId) return this.toast('FilmId and CategoryId required');

    this.filmSvc.updateCategory(filmId, categoryId).subscribe({
      next: _ => this.toast('Category linked'),
      error: err => this.toast(err?.error?.message || 'Update category failed')
    });
  }

  private toast(msg: string) {
    this.snack.open(msg, 'OK', { duration: 2500 });
  }
}
