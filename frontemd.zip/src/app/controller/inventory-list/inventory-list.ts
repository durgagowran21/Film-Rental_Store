import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { InventoryDTO } from '../../entity/inventory-entity';
import { InventoryServ } from '../../Service/inventory-serv';

@Component({
  selector: 'app-inventory-list',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './inventory-list.html',
  styleUrls: ['./inventory-list.css']
})
export class InventoryListComponent {
  inventories: InventoryDTO[] = [];
  filmId: number = 0;
  storeId: number = 0;
  newInventory: InventoryDTO = { inventoryId: 0, filmId: 0, storeId: 0, lastUpdate: '' };
  loading = false;

  constructor(private inventoryServ: InventoryServ) {}

  loadAll() {
    this.loading = true;
    this.inventoryServ.getAllFilmInventories().subscribe({
      next: res => { this.inventories = res; this.loading = false; },
      error: err => { alert('Load failed: ' + err.message); this.loading = false; }
    });
  }

  loadByFilm() {
    if (!this.filmId) return alert('Enter film ID');
    this.loading = true;
    this.inventoryServ.getStoreInventoriesByFilm(this.filmId).subscribe({
      next: res => { this.inventories = res; this.loading = false; },
      error: err => { alert('Load failed: ' + err.message); this.loading = false; }
    });
  }

  loadByStore() {
    if (!this.storeId) return alert('Enter store ID');
    this.loading = true;
    this.inventoryServ.getFilmInventoriesByStore(this.storeId).subscribe({
      next: res => { this.inventories = res; this.loading = false; },
      error: err => { alert('Load failed: ' + err.message); this.loading = false; }
    });
  }

  addInventory() {
    if (!this.newInventory.filmId || !this.newInventory.storeId) return alert('Enter film and store ID');
    this.newInventory.lastUpdate = new Date().toISOString();
    this.inventoryServ.addFilmToStore(this.newInventory).subscribe({
      next: res => { alert('Added'); this.loadAll(); },
      error: err => alert('Add failed: ' + err.message)
    });
  }
}