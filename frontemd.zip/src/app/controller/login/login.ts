import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { Router, RouterLink } from '@angular/router';

@Component({
  selector: 'app-login',
  standalone: true,
  imports: [CommonModule, FormsModule, RouterLink],
 templateUrl: './login.html',
  styleUrls: ['./login.css'],
})
export class LoginComponent {
 
  // Declare the fields used by the template
  role: 'customer' | 'staff' = 'customer';
  email: string = '';
  password: string = '';

  constructor(private router: Router) {}

  onLogin(): void {
    if (!this.email || !this.password || this.password.length < 4||!this.email.includes('@')||!this.email.includes('.')||this.password.length > 15) {
      alert('Invalid credentials ,Please enter valid details');

      return;
    }

    // Save session (localStorage)
    const user = { role: this.role, email: this.email, name: this.email.split('@')[0] || this.email };
    localStorage.setItem('vr_user', JSON.stringify(user));

    // Navigate by role
     
 const target = this.role === 'staff' ? '/staff' : '/customer';
    this.router.navigate([target]);
  }
  GoToRole():void{
    const target = this.role === 'staff' ? '/staff' : '/customer';
    this.router.navigate([target]);
  }
   
}

  // login() {
  //   if (!this.username.trim() || !this.password.trim()) {
  //     alert('Please enter username and password');
  //     return;
  //   }
  //   this.loading = true;
  //   // Simulate login - in real app, call auth service
  //   setTimeout(() => {
  //     this.loading = false;
  //     // For demo, always succeed and navigate to actor
  //     this.router.navigate(['/actor']);
  //   }, 1000);
  // }
  




 

