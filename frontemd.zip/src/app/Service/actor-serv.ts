import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';
import { ActorEntity, Film, ActorDto } from '../entity/actor-entity';
import { environment } from '../../environments/environment';

@Injectable({
  providedIn: 'root',
})
export class ActorServ {
  
  private baseUrl = `${environment.apiBaseUrl}/api/actors`;
 
  constructor(private http: HttpClient) {}
 
  searchByLastName(ln: string): Observable<ActorDto[]> {
    return this.http.get<ActorDto[]>(`${this.baseUrl}/lastname/${encodeURIComponent(ln)}`);
  }
  searchByFirstName(fn: string): Observable<ActorDto[]> {
    return this.http.get<ActorDto[]>(`${this.baseUrl}/firstname/${encodeURIComponent(fn)}`);
  }
 
  updateLastName(id: number, lastName: string): Observable<void> {
    const headers = new HttpHeaders({ 'Content-Type': 'text/plain' });
    return this.http.put<void>(`${this.baseUrl}/update/lastname/${id}`, lastName, { headers });
  }
  updateFirstName(id: number, firstName: string): Observable<void> {
    const headers = new HttpHeaders({ 'Content-Type': 'text/plain' });
    return this.http.put<void>(`${this.baseUrl}/update/firstname/${id}`, firstName, { headers });
  }
 
  getTopTenByFilmCount(): Observable<ActorDto[]> {
    return this.http.get<ActorDto[]>(`${this.baseUrl}/toptenbyfilmcount`);
  }
 
  create(actor: ActorDto): Observable<string> {
    // Controller returns String messages → responseType: 'text'
    return this.http.post(`${this.baseUrl}/post`, actor, { responseType: 'text' });
  }
 
  addFilmsToActor(actorId: number, filmIds: number[]): Observable<string> {
    return this.http.put(`${this.baseUrl}/${actorId}/film`, filmIds, { responseType: 'text' });
  }
 
  getFilmsByActor(id: number): Observable<Film[]> {
    return this.http.get<Film[]>(`${this.baseUrl}/${id}/films`);
  }
}
 
 