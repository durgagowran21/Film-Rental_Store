// import { Injectable } from '@angular/core';

// @Injectable({
//   providedIn: 'root',
// })
// export class Film {
  
// }


import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders, HttpParams } from '@angular/common/http';
import { environment } from '../../environments/environment';
import { Observable } from 'rxjs';
import { FilmDto, ActorDto, FilmCountByYear } from '../entity/film.model';

@Injectable({ providedIn: 'root' })
export class FilmService {
  private base = `${environment.apiBaseUrl}/api/films`;

  constructor(private http: HttpClient) {}

  // Customer-visible endpoints
  getAll(): Observable<FilmDto[]> {
    return this.http.get<FilmDto[]>(`${this.base}`);
  }

  // findByTitle(title: string): Observable<FilmDto> {
  //   return this.http.get<FilmDto>(`${this.base}/title/${encodeURIComponent(title)}`);
  // }

findByTitle(title: string) {
  const url = `${this.base}/title/${encodeURIComponent(title)}`;
  console.log('[FilmService] GET', url); // <— log
  return this.http.get<FilmDto>(url);
}



  findByReleaseYear(year: number): Observable<FilmDto[]> {
    return this.http.get<FilmDto[]>(`${this.base}/year/${year}`);
  }

  findDurationGt(rd: number): Observable<FilmDto[]> {
    return this.http.get<FilmDto[]>(`${this.base}/duration/gt/${rd}`);
  }

  findDurationLt(rd: number): Observable<FilmDto[]> {
    return this.http.get<FilmDto[]>(`${this.base}/duration/lt/${rd}`);
  }

  findRateGt(rate: number): Observable<FilmDto[]> {
    return this.http.get<FilmDto[]>(`${this.base}/rate/gt/${rate}`);
  }

  findRateLt(rate: number): Observable<FilmDto[]> {
    return this.http.get<FilmDto[]>(`${this.base}/rate/lt/${rate}`);
  }

  findLengthGt(length: number): Observable<FilmDto[]> {
    return this.http.get<FilmDto[]>(`${this.base}/length/gt/${length}`);
  }

  findLengthLt(length: number): Observable<FilmDto[]> {
    return this.http.get<FilmDto[]>(`${this.base}/length/lt/${length}`);
  }

  findBetweenYear(from: number, to: number): Observable<FilmDto[]> {
    return this.http.get<FilmDto[]>(`${this.base}/betweenyear/${from}/${to}`);
  }

  findRatingLt(rating: number): Observable<FilmDto[]> {
    return this.http.get<FilmDto[]>(`${this.base}/rating/lt/${rating}`);
  }

  findRatingGt(rating: number): Observable<FilmDto[]> {
    return this.http.get<FilmDto[]>(`${this.base}/rating/gt/${rating}`);
  }

  findByLanguage(lang: string): Observable<FilmDto[]> {
    return this.http.get<FilmDto[]>(`${this.base}/language/${encodeURIComponent(lang)}`);
  }

  countByYear(): Observable<FilmCountByYear> {
    return this.http.get<FilmCountByYear>(`${this.base}/countbyyear`);
  }

  getActorsOfFilm(id: number): Observable<ActorDto[]> {
    return this.http.get<ActorDto[]>(`${this.base}/${id}/actors`);
  }

  getFilmsByCategory(category: string): Observable<FilmDto[]> {
    return this.http.get<FilmDto[]>(`${this.base}/category/${encodeURIComponent(category)}`);
  }

  // Staff-only endpoints (visible when Staff is selected)
  addFilm(payload: FilmDto): Observable<string> {
    return this.http.post(`${this.base}/post`, payload, { responseType: 'text' });
  }

  updateTitle(id: number, title: string): Observable<FilmDto> {
    // Backend expects @RequestBody String; application/json with "title" string works; text/plain also works.
    const headers = new HttpHeaders({ 'Content-Type': 'application/json' });
    return this.http.put<FilmDto>(`${this.base}/update/title/${id}`, JSON.stringify(title), { headers });
    // If you prefer text/plain:
    // const headers = new HttpHeaders({ 'Content-Type': 'text/plain' });
    // return this.http.put<FilmDto>(`${this.base}/update/title/${id}`, title, { headers });
  }

  updateReleaseYear(id: number, year: number): Observable<FilmDto> {
    return this.http.put<FilmDto>(`${this.base}/update/releaseyear/${id}`, year);
  }

  updateRentalDuration(id: number, rentalDuration: number): Observable<FilmDto> {
    return this.http.put<FilmDto>(`${this.base}/update/rentalduration/${id}`, rentalDuration);
  }

  updateRentalRate(id: number, rentalRate: number): Observable<FilmDto> {
    return this.http.put<FilmDto>(`${this.base}/update/rentalrate/${id}`, rentalRate);
  }

  updateRating(id: number, rating: number): Observable<FilmDto> {
    return this.http.put<FilmDto>(`${this.base}/update/rating/${id}`, rating);
  }

  updateLanguage(id: number, langId: number): Observable<FilmDto> {
    return this.http.put<FilmDto>(`${this.base}/update/language/${id}`, langId);
  }

  assignActorsToFilm(filmId: number, actorIds: number[]): Observable<string> {
    return this.http.put(`${this.base}/${filmId}/actors`, actorIds, { responseType: 'text' });
  }

  updateCategory(id: number, categoryId: number): Observable<any> {
    return this.http.put(`${this.base}/update/category/${id}`, categoryId);
  }
}

