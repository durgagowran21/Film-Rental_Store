// import { Injectable } from '@angular/core';

// @Injectable({
//   providedIn: 'root',
// })
// export class Category {
  
// }


import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { environment } from '../../environments/environment';
import { Observable } from 'rxjs';
import { Category } from '../entity/film.model';

@Injectable({ providedIn: 'root' })
export class CategoryService {
  private base = `${environment.apiBaseUrl}/api/category`; // per your controller

  constructor(private http: HttpClient) {}

  // Only create endpoint is defined in your controller
  createCategory(category: Category): Observable<string> {
    return this.http.post(`${this.base}/post`, category, { responseType: 'text' });
  }
}
