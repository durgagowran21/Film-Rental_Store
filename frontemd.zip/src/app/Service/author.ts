
import { Injectable } from '@angular/core';

@Injectable({ providedIn: 'root' })
export class AuthService {
  private user: any = null;

  login(role: string, email: string) {
    this.user = { role, email };
    localStorage.setItem('vr_user', JSON.stringify(this.user));
  }

  getUser() {
    return this.user || JSON.parse(localStorage.getItem('vr_user') || 'null');
  }

  logout() {
    this.user = null;
    localStorage.removeItem('vr_user');
  }

  isLoggedIn() {
    return !!this.getUser();
  }

  hasRole(role: string) {
    const user = this.getUser();
    return user && user.role === role;
  }
}
