import { Injectable, inject } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';



// From 'src/app/service' -> up two levels to 'src/environments'
import { environment } from '../../environments/environment';
import { CustomerDto, StaffDTO, StoreDto, StoreModel } from '../entity/store-entity';

@Injectable({ providedIn: 'root' })
export class StoreServ {
  private readonly http = inject(HttpClient);
  private readonly base = `${environment.apiBaseUrl}/api/stores`;

  private enc(v: string) { return encodeURIComponent(v); }

  // GET /api/stores/all -> List<Store> (ENTITY)
  getAllStores(): Observable<StoreModel[]> {
    return this.http.get<StoreModel[]>(`${this.base}/all`);
  }

  // POST /api/stores/add -> Store (ENTITY)
  addStore(dto: StoreDto): Observable<StoreModel> {
    return this.http.post<StoreModel>(`${this.base}/add`, dto);
  }

  // PUT /api/stores/{storeId}/address/{addressId} -> StoreDto
  assignAddressToStore(storeId: number, addressId: number): Observable<StoreDto> {
    return this.http.put<StoreDto>(`${this.base}/${storeId}/address/${addressId}`, {});
  }

  // GET /api/stores/city/{city} -> List<StoreDto>
  getStoresByCity(city: string): Observable<StoreDto[]> {
    return this.http.get<StoreDto[]>(`${this.base}/city/${this.enc(city)}`);
  }

  // ✅ GET /api/stores/country/{country} -> List<StoreDto>
  getStoresByCountry(country: string): Observable<StoreDto[]> {
    return this.http.get<StoreDto[]>(`${this.base}/country/${this.enc(country)}`);
  }

  // GET /api/stores/phone/{phone} -> StoreDto
  getStoreByPhone(phone: string): Observable<StoreDto> {
    return this.http.get<StoreDto>(`${this.base}/phone/${this.enc(phone)}`);
  }

  // PUT /api/stores/update/{storeId}/{phone} -> String
  updateStorePhoneNumber(storeId: number, phone: string): Observable<string> {
    return this.http.put(`${this.base}/update/${storeId}/${this.enc(phone)}`, {}, { responseType: 'text' });
  }

  // GET /api/stores/staff/{storeId} -> List<StaffDTO>
  getStaffByStoreId(storeId: number): Observable<StaffDTO[]> {
    return this.http.get<StaffDTO[]>(`${this.base}/staff/${storeId}`);
  }

  // GET /api/stores/customer/{storeId} -> List<CustomerDto>
  getCustomersByStoreId(storeId: number): Observable<CustomerDto[]> {
    return this.http.get<CustomerDto[]>(`${this.base}/customer/${storeId}`);
  }
}

