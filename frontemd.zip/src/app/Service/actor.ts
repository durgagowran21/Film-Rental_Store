// import { Injectable } from '@angular/core';

// @Injectable({
//   providedIn: 'root',
// })
// export class Actor {
  
// }


import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { environment } from '../../environments/environment';
import { Observable } from 'rxjs';
import { ActorDto } from '../entity/film.model';

@Injectable({ providedIn: 'root' })
export class ActorService {
  private base = `${environment.apiBaseUrl}/api/actors`;

  constructor(private http: HttpClient) {}

  getByLastName(lastName: string): Observable<ActorDto[]> {
    return this.http.get<ActorDto[]>(`${this.base}/lastname/${encodeURIComponent(lastName)}`);
  }

  getByFirstName(firstName: string): Observable<ActorDto[]> {
    return this.http.get<ActorDto[]>(`${this.base}/firstname/${encodeURIComponent(firstName)}`);
  }

  getTopTenByFilmCount(): Observable<ActorDto[]> {
    return this.http.get<ActorDto[]>(`${this.base}/toptenbyfilmcount`);
  }

  createActor(actor: ActorDto): Observable<string> {
    return this.http.post(`${this.base}/post`, actor, { responseType: 'text' });
  }

  // NOTE: consumes = "text/plain" – we must send text/plain.
  updateLastName(id: number, lastName: string): Observable<void> {
    const headers = new HttpHeaders({ 'Content-Type': 'text/plain' });
    return this.http.put<void>(`${this.base}/update/lastname/${id}`, lastName, { headers });
  }

  updateFirstName(id: number, firstName: string): Observable<void> {
    const headers = new HttpHeaders({ 'Content-Type': 'text/plain' });
    return this.http.put<void>(`${this.base}/update/firstname/${id}`, firstName, { headers });
  }

  assignFilmsToActor(actorId: number, filmIds: number[]): Observable<string> {
    return this.http.put(`${this.base}/${actorId}/film`, filmIds, { responseType: 'text' });
  }

  getFilmsByActorId(id: number): Observable<any[]> {
    return this.http.get<any[]>(`${this.base}/${id}/films`);
  }
}

