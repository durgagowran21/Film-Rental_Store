import { TestBed } from '@angular/core/testing';

import { CustServ } from './cust-serv';

describe('CustServ', () => {
  let service: CustServ;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(CustServ);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
