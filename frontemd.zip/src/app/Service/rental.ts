
import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { environment } from '../../environments/environment';
import { Observable } from 'rxjs';
import { RentalDto } from '../entity/rental';

@Injectable({ providedIn: 'root' })
export class RentalService {
  private base = `${environment.apiBaseUrl}/api/rentals`;

  constructor(private http: HttpClient) {}

  // POST /api/rentals/add -> returns plain String
  addRental(dto: RentalDto): Observable<string> {
    return this.http.post(`${this.base}/add`, dto, { responseType: 'text' });
  }

  // GET /api/rentals/customer/{id} -> List<RentalDto>
  getRentalsByCustomer(id: number): Observable<RentalDto[]> {
    return this.http.get<RentalDto[]>(`${this.base}/customer/${id}`);
  }

  // GET /api/rentals/toptenfilms -> List<RentalDto>
  getTopTenFilms(): Observable<RentalDto[]> {
    return this.http.get<RentalDto[]>(`${this.base}/toptenfilms`);
  }

  // GET /api/rentals/toptenfilms/store/{id} -> List<RentalDto>
  getTopTenFilmsByStore(storeId: number): Observable<RentalDto[]> {
    return this.http.get<RentalDto[]>(`${this.base}/toptenfilms/store/${storeId}`);
  }

  // GET /api/rentals/due/store/{id} -> Map<Long, String>
  getPendingReturnsByStore(storeId: number): Observable<Record<number, string>> {
    return this.http.get<Record<number, string>>(`${this.base}/due/store/${storeId}`);
  }

  // POST /api/rentals/update/returndate/{id} -> RentalDto
  // Body is required to be a LocalDateTime string (e.g., "2025-12-28T14:10:00")
  updateReturnDate(rentalId: number, returnDateISO: string): Observable<RentalDto> {
    const headers = new HttpHeaders({ 'Content-Type': 'application/json' });
    // Backend expects the raw JSON string of the date/time
    return this.http.post<RentalDto>(`${this.base}/update/returndate/${rentalId}`, returnDateISO, { headers });
  }
}

