import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { CityDto } from '../entity/city-entity';
import { environment } from '../../environments/environment';

@Injectable({
  providedIn: 'root',
})
export class CityServ {
  private baseUrl = `${environment.apiBaseUrl}/api/city`;

  constructor(private http: HttpClient) {}

  createCity(city: CityDto): Observable<string> {
    return this.http.post<string>(`${this.baseUrl}/post`, city);
  }
}