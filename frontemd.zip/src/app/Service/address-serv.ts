import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { AddressDto } from '../entity/address-entity';
import { environment } from '../../environments/environment';

@Injectable({
  providedIn: 'root',
})
export class AddressServ {
  private baseUrl = `${environment.apiBaseUrl}/api/address`;

  constructor(private http: HttpClient) {}

  createAddress(address: AddressDto): Observable<string> {
    return this.http.post<string>(`${this.baseUrl}/post`, address);
  }
}