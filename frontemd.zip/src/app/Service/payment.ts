import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { environment } from '../../environments/environment';
import { Observable } from 'rxjs';
import { PaymentDTO } from '../entity/payment';


@Injectable({ providedIn: 'root' })
export class PaymentService {
  private base = `${environment.apiBaseUrl}/api/payment`;

  constructor(private http: HttpClient) {}

  // PUT /api/payment/add -> returns plain String
  addPayment(dto: PaymentDTO): Observable<string> {
    return this.http.put(`${this.base}/add`, dto, { responseType: 'text' });
  }

  // GET /api/payment/revenue/datewise -> Map<LocalDate, Double>
  getRevenueDatewise(): Observable<Record<string, number>> {
    return this.http.get<Record<string, number>>(`${this.base}/revenue/datewise`);
  }

  // GET /api/payment/revenue/datewise/store/{id}
  getRevenueByStoreDatewise(storeId: number): Observable<Record<string, number>> {
    return this.http.get<Record<string, number>>(`${this.base}/revenue/datewise/store/${storeId}`);
  }

  // GET /api/payment/revenue/filmwise -> Map<String, Double>
  getRevenueFilmwise(): Observable<Record<string, number>> {
    return this.http.get<Record<string, number>>(`${this.base}/revenue/filmwise`);
  }

  // GET /api/payment/revenue/film/{id} -> Map<String, Double> (e.g., "Film - Address": amount)
  getRevenueByFilmStorewise(filmId: number): Observable<Record<string, number>> {
    return this.http.get<Record<string, number>>(`${this.base}/revenue/film/${filmId}`);
  }

  // GET /api/payment/revenue/films/store/{id} -> Map<String, Double> (filmTitle: amount)
  getRevenueFilmsByStore(storeId: number): Observable<Record<string, number>> {
    return this.http.get<Record<string, number>>(`${this.base}/revenue/films/store/${storeId}`);
  }
}
