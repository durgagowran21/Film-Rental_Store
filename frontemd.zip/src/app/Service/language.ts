// import { Injectable } from '@angular/core';

// @Injectable({
//   providedIn: 'root',
// })
// export class Language {
  
// }


import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

import { Observable } from 'rxjs';
import { Language } from '../entity/film.model';
import { environment } from '../../environments/environment';

@Injectable({ providedIn: 'root' })
export class LanguageService {
  private base = `${environment.apiBaseUrl}/api/languages`;

  constructor(private http: HttpClient) {}

  getAll(): Observable<Language[]> {
    return this.http.get<Language[]>(`${this.base}`);
  }

  createLanguage(lang: Language): Observable<string> {
    return this.http.post(`${this.base}/post`, lang, { responseType: 'text' });
  }
}
