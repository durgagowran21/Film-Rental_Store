import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';


import { Observable } from 'rxjs';
import {
  StaffFirstNameUpdateRequest,
  StaffLastNameUpdateRequest,
  StaffEmailUpdateRequest,
  StaffPhoneUpdateRequest,
  StaffStoreAssignRequest,
  StaffAddressAssignRequest,
  StaffEntity,
  
} from '../entity/staff-entity';
import { environment } from '../../environments/environment';

@Injectable({
  providedIn: 'root',
})
export class StaffServ {
  private apiUrl = 'http://localhost:8080/api/staffs';
private baseUrl = `${environment.apiBaseUrl}/api/staffs`;
  constructor(private http: HttpClient) {}
  // getAllStaffs(): Observable<StaffEntity[]> {
  //   return this.http.get<StaffEntity[]>(this.apiUrl);
  // }
  
 // Create
  createStaff(payload: StaffEntity): Observable<StaffEntity> {
    return this.http.post<StaffEntity>(`${this.apiUrl}`, payload);
  }


 findByLastName(lastName: string): Observable<StaffEntity[]> {
    return this.http.get<StaffEntity[]>(`${this.apiUrl}/${encodeURIComponent(lastName)}`);
  }

findByFirstName(firstName: string): Observable<StaffEntity[]> {
    return this.http.get<StaffEntity[]>(`${this.apiUrl}/${encodeURIComponent(firstName)}`);
  }

findByEmail(email: string): Observable<StaffEntity[]> {
    return this.http.get<StaffEntity[]>(`${this.apiUrl}/${encodeURIComponent(email)}`);
  }

findByCity(city: string): Observable<StaffEntity[]> {
    return this.http.get<StaffEntity[]>(`${this.apiUrl}/city/${encodeURIComponent(city)}`);
  }
findByCountry(country: string): Observable<StaffEntity[]> {
    return this.http.get<StaffEntity[]>(`${this.apiUrl}/country/${encodeURIComponent(country)}`);
  }

findByPhone(phone: string): Observable<StaffEntity[]> {
    return this.http.get<StaffEntity[]>(`${this.apiUrl}/${encodeURIComponent(phone)}`);
  }

  updateFirstName(id: number, payload: StaffFirstNameUpdateRequest): Observable<StaffEntity> {
    return this.http.put<StaffEntity>(`${this.apiUrl}/${id}/first-name`, payload);
  }
  updateLastName(id: number, payload: StaffLastNameUpdateRequest): Observable<StaffEntity> {
    return this.http.put<StaffEntity>(`${this.apiUrl}/${id}/last-name`, payload);
  }
  updateEmail(id: number, payload: StaffEmailUpdateRequest): Observable<StaffEntity> {
    return this.http.put<StaffEntity>(`${this.apiUrl}/${id}/email`, payload);
  }

  updatePhone(id: number, payload: StaffPhoneUpdateRequest): Observable<StaffEntity> {
    return this.http.put<StaffEntity>(`${this.apiUrl}/${id}/phone`, payload);
  }
  assignStore(id: number, payload: StaffStoreAssignRequest): Observable<StaffEntity> {
    return this.http.put<StaffEntity>(`${this.apiUrl}/${id}/assign-store`, payload);
  }
  assignAddress(id: number, payload: StaffAddressAssignRequest): Observable<StaffEntity> {
    return this.http.put<StaffEntity>(`${this.apiUrl}/${id}/assign-address`, payload);
  }
}