import { TestBed } from '@angular/core/testing';

import { StaffServ } from './staff-serv';

describe('StaffServ', () => {
  let service: StaffServ;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(StaffServ);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
