import { TestBed } from '@angular/core/testing';

import { ActorServ } from './actor-serv';

describe('ActorServ', () => {
  let service: ActorServ;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(ActorServ);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
