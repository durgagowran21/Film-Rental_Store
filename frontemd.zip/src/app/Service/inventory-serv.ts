import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { InventoryDTO } from '../entity/inventory-entity';
import { environment } from '../../environments/environment';

@Injectable({
  providedIn: 'root',
})
export class InventoryServ {
  private baseUrl = `${environment.apiBaseUrl}/api/inventory`;

  constructor(private http: HttpClient) {}

  getAllFilmInventories(): Observable<InventoryDTO[]> {
    return this.http.get<InventoryDTO[]>(`${this.baseUrl}/films`);
  }

  getFilmInventoriesByStore(storeId: number): Observable<InventoryDTO[]> {
    return this.http.get<InventoryDTO[]>(`${this.baseUrl}/store/${storeId}`);
  }

  getStoreInventoriesByFilm(filmId: number): Observable<InventoryDTO[]> {
    return this.http.get<InventoryDTO[]>(`${this.baseUrl}/film/${filmId}`);
  }

  getFilmInventoryByStore(filmId: number, storeId: number): Observable<InventoryDTO> {
    return this.http.get<InventoryDTO>(`${this.baseUrl}/film/${filmId}/store/${storeId}`);
  }

  addFilmToStore(inventory: InventoryDTO): Observable<InventoryDTO> {
    return this.http.post<InventoryDTO>(`${this.baseUrl}/add`, inventory);
  }
}