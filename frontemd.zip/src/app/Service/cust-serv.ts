 
import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';
import { environment } from '../../environments/environment';
import { CustomerDto, Store } from '../entity/customer-entity';

 
@Injectable({ providedIn: 'root' })
export class CustomerService {
  private readonly baseUrl = `${environment.apiBaseUrl}/api/customers`;
 
  constructor(private http: HttpClient) {}
 
  // CREATE (plain text response from backend)
  createCustomer(payload: CustomerDto): Observable<string> {
    return this.http.post(
      `${this.baseUrl}/post`,
      payload,
      { responseType: 'text' as const }  
    );
  }
 
  // READ - filters
  getByLastName(lastName: string): Observable<CustomerDto[]> {
    return this.http.get<CustomerDto[]>(`${this.baseUrl}/lastname/${encodeURIComponent(lastName)}`);
  }
  getByFirstName(firstName: string): Observable<CustomerDto[]> {
    return this.http.get<CustomerDto[]>(`${this.baseUrl}/firstname/${encodeURIComponent(firstName)}`);
  }
  getByEmail(email: string): Observable<CustomerDto[]> {
    return this.http.get<CustomerDto[]>(`${this.baseUrl}/email/${encodeURIComponent(email)}`);
  }
  getActive(): Observable<CustomerDto[]> { return this.http.get<CustomerDto[]>(`${this.baseUrl}/active`); }
  getInactive(): Observable<CustomerDto[]> { return this.http.get<CustomerDto[]>(`${this.baseUrl}/inactive`); }
  getByPhone(phone: string): Observable<CustomerDto[]> {
    return this.http.get<CustomerDto[]>(`${this.baseUrl}/phone/${encodeURIComponent(phone)}`);
  }
  getByCity(city: string): Observable<CustomerDto[]> {
    return this.http.get<CustomerDto[]>(`${this.baseUrl}/city/${encodeURIComponent(city)}`);
  }
  getByCountry(country: string): Observable<CustomerDto[]> {
    return this.http.get<CustomerDto[]>(`${this.baseUrl}/country/${encodeURIComponent(country)}`);
  }
 
  // UPDATE - raw text bodies
  updateFirstName(id: number, firstName: string): Observable<CustomerDto> {
    const headers = new HttpHeaders({ 'Content-Type': 'text/plain' });
    return this.http.put<CustomerDto>(`${this.baseUrl}/update/${id}/firstname`, firstName, { headers });
  }
  updateLastName(id: number, lastName: string): Observable<CustomerDto> {
    const headers = new HttpHeaders({ 'Content-Type': 'text/plain' });
    return this.http.put<CustomerDto>(`${this.baseUrl}/update/${id}/lastname`, lastName, { headers });
  }
  updateEmail(id: number, email: string): Observable<CustomerDto> {
    const headers = new HttpHeaders({ 'Content-Type': 'text/plain' });
    return this.http.put<CustomerDto>(`${this.baseUrl}/updateemail/${id}`, email, { headers });
  }
  updatePhone(id: number, phone: string): Observable<CustomerDto> {
    const headers = new HttpHeaders({ 'Content-Type': 'text/plain' });
    return this.http.put<CustomerDto>(`${this.baseUrl}/updatephone/${id}`, phone, { headers });
  }
 
  // ASSIGN
  assignAddress(customerId: number, addressId: number): Observable<CustomerDto> {
    return this.http.put<CustomerDto>(`${this.baseUrl}/${customerId}/${addressId}`, {});
  }
  assignStore(customerId: number, store: Store): Observable<CustomerDto> {
    return this.http.put<CustomerDto>(`${this.baseUrl}/update/${customerId}/store`, store);
  }
}
 
 