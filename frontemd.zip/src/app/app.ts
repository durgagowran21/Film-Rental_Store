import { Component, signal } from '@angular/core';
import { RouterOutlet } from '@angular/router';
import { PaymentFormComponent } from './controller/payment-form/payment-form';
import { RentalReturnUpdateComponent } from './controller/rental-return-update/rental-return-update';
import { TopTenFilmsComponent } from './controller/rental-top-ten-films/rental-top-ten-films';
import { RentalsByCustomerComponent } from './controller/rentals-by-customer/rentals-by-customer';
import { TopTenFilmsByStoreComponent } from './controller/rental-top-ten-films-by-store/rental-top-ten-films-by-store';
import { RentalsCreateComponent } from './controller/rentals-create/rentals-create';
import { StaffContro } from './controller/staff-contro/staff-contro';
import { Customer } from "./controller/customer/customer";
import { ActorEditComponent } from "./controller/actor-edit/actor-edit";
import { ActorListComponent } from "./controller/actor-list/actor-list";


@Component({
  selector: 'app-root',
  imports: [RouterOutlet, Customer, ActorEditComponent, ActorListComponent],
  templateUrl: './app.html',
  styleUrl: './app.css'
})
export class App {
  protected readonly title = signal('filmRental');
}
