import { Routes } from '@angular/router';
import { ActorListComponent } from './controller/actor-list/actor-list';
import { ActorEditComponent } from './controller/actor-edit/actor-edit';
import { ActorFilm } from './controller/actor-film/actor-film';
import { StaffContro } from './controller/staff-contro/staff-contro';
import path from 'path';

import { LoginComponent } from './controller/login/login';
import { InventoryListComponent } from './controller/inventory-list/inventory-list';
import { AddressComponent } from './controller/address/address';
import { CategoryComponent } from './controller/category/category';
import { CityComponent } from './controller/city/city';
import { Component } from '@angular/core';
import { Customer } from './controller/customer/customer';
import { StoreContro } from './controller/store-contro/store-contro';
import { FilmDetailComponent } from './controller/film-detail/film-detail';
import { FilmManageComponent } from './controller/film-manage/film-manage';
import { FilmListComponent } from './controller/film-list/film-list';
import { PaymentFormComponent } from './controller/payment-form/payment-form';
import { PaymentRevenueComponent } from './controller/payment-revenue/payment-revenue';
import { RentalReturnUpdateComponent } from './controller/rental-return-update/rental-return-update';
import { TopTenFilmsComponent } from './controller/rental-top-ten-films/rental-top-ten-films';
import { TopTenFilmsByStoreComponent } from './controller/rental-top-ten-films-by-store/rental-top-ten-films-by-store';
import { RentalsByCustomerComponent } from './controller/rentals-by-customer/rentals-by-customer';
import { RentalsCreateComponent } from './controller/rentals-create/rentals-create';
import { PendingReturnsComponent } from './controller/rentals-pending-returns/rentals-pending-returns';

export const routes: Routes = [
    {
        path: '',
        component: LoginComponent
    },
    {
        path: 'actorlist',
        component: ActorListComponent
    },
    {
        path: 'edit',
        component: ActorEditComponent
    },
    {
        path: 'actor-film',
        component: ActorFilm
    },
    {
        path: 'staff',
        component: StaffContro
    },
    {
        path: 'inventory',
        component: InventoryListComponent
    },
    {
        path: 'address',
        component: AddressComponent
    },
    {
        path: 'category',
        component: CategoryComponent
    },
    {
        path: 'city',
        component: CityComponent
    },
    {
        path:'customer',
        component:Customer
    },
    {
        path:'Store',
        component:StoreContro
    },
    { 
        path: '**', 
        redirectTo: 'login' 
    },
    {
        path:'filmdetails',
        component:FilmDetailComponent
    },
    {
        path:'filmmanage',
        component:FilmManageComponent
    },
    {
        path:'FilmList',
        component:FilmListComponent
    },
    {
        path:'paymentForm',
        component:PaymentFormComponent
    },
    {
        path:'paymentRevenue',
        component:PaymentRevenueComponent
    },
    {
        path:'rentalReturnUpdate',
        component:RentalReturnUpdateComponent
    },
    {
        path:'topTenFilms',
        component:TopTenFilmsComponent
    },
    {
        path:'topTenFilmsByStore',
        component:TopTenFilmsByStoreComponent
    },
    {
        path:'rentalsByCustomer',
        component:RentalsByCustomerComponent
    },
     {
        path:'rentalsCreate',
        component:RentalsCreateComponent
    },
     {
        path:'pendingReturns',
        component:PendingReturnsComponent
    }


];

    
