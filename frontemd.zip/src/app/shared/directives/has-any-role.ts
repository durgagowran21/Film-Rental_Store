
// src/app/shared/directives/has-any-role.ts
import { Directive, Input, TemplateRef, ViewContainerRef } from '@angular/core';
import { RoleService } from '../../core/role.service';

@Directive({ selector: '[appHasAnyRole]' })
export class HasAnyRoleDirective {
  private roles: Array<'customer' | 'staff'> = [];

  constructor(
    private tpl: TemplateRef<any>,
    private vcr: ViewContainerRef,
    private roleSvc: RoleService
  ) {}

  @Input() set appHasAnyRole(roles: Array<'customer' | 'staff'>) {
    this.roles = roles ?? [];
    this.update();
  }

  private update() {
    this.vcr.clear();
    const ok =
      (this.roleSvc.isCustomer() && this.roles.includes('customer')) ||
      (this.roleSvc.isStaff() && this.roles.includes('staff'));
    if (ok) this.vcr.createEmbeddedView(this.tpl);
  }
}
