import { HasAnyRole } from './has-any-role';

describe('HasAnyRole', () => {
  it('should create an instance', () => {
    const directive = new HasAnyRole();
    expect(directive).toBeTruthy();
  });
});
