
import { Directive, Input, TemplateRef, ViewContainerRef } from '@angular/core';
import { RoleService } from '../../core/role.service';

@Directive({
  selector: '[appHasRole,]',
  standalone: true, // ✅ make it standalone
})
export class HasRoleDirective {
  private role!: 'customer' | 'staff';

  constructor(
    private tpl: TemplateRef<any>,
    private vcr: ViewContainerRef,
    private roleSvc: RoleService
  ) {}

  @Input() set appHasRole(role: 'customer' | 'staff') {
    this.role = role;
    this.update();
  }

  private update() {
    this.vcr.clear();
    const ok = this.role === 'customer' ? this.roleSvc.isCustomer() : this.roleSvc.isStaff();
    if (ok) this.vcr.createEmbeddedView(this.tpl);
  }
}
