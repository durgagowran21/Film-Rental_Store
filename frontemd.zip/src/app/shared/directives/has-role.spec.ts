import { HasRole } from './has-role';

describe('HasRole', () => {
  it('should create an instance', () => {
    const directive = new HasRole();
    expect(directive).toBeTruthy();
  });
});
