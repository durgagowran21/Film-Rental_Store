
import { Routes } from '@angular/router';
import { Films } from './components/films/films';
import { About } from './components/about/about';
import { Contact } from './components/contact/contact';
import { SignInComponent } from './components/sign-in/sign-in';
import { SignUpComponent } from './components/sign-up/sign-up';
import { Home } from './components/home/home';



export const routes: Routes = [
  { path: '', component: Home },              
  { path: 'films', component: Films },        // Films
  { path: 'about', component: About },        // About
  { path: 'contact', component: Contact},    // Contact
  { path: 'sign-in', component: SignInComponent },     // Sign In
  { path: 'sign-up', component: SignUpComponent },     // Sign Up
  { path: '**', redirectTo: '' }                       // Fallback
];
