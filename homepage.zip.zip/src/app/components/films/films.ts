import { Component } from '@angular/core';

@Component({
  selector: 'app-films',
  imports: [],
  templateUrl: './films.html',
  styleUrl: './films.css',
})
export class Films {

}
